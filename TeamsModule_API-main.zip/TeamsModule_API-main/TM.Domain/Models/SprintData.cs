﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TM.Domain.Models
{
    public class SprintData
    {
        [Key]
        public Guid SprintDataUID { get; set; } = Guid.NewGuid();
        public Guid SprintUID { get; set; }
        public int Id { get; set; }
        public int ParentId { get; set; }
        public string? WorkItemType { get; set; } = string.Empty;
        public string? Title { get; set; } = string.Empty;
        public string? AssignedTo { get; set; } = string.Empty;
        public string? State { get; set; } = string.Empty;
        public string? Tags { get; set; } = string.Empty;
        public string? ResolvedBy { get; set; } = string.Empty;
        public double CompletedWork { get; set; } = 0.0;
        public string? Severity { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; }
        public double StoryPoints { get; set; } = 0.0;

    }
}
