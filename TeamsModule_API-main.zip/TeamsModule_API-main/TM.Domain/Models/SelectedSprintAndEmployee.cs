﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TM.Domain.Models
{
    public class SelectedSprintAndEmployees
    {
        public string[]? SprintUIDs { get; set; }

        public int[]? Team1EmployeeIds { get; set; }

        public int[]? Team2EmployeeIds { get; set; }
    }
}
