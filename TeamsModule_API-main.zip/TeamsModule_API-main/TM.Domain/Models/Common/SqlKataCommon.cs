﻿namespace TM.Domain.Models.Common
{
    public static class SqlKataCommon
    {
        public const string Table_DevOpsSprintData = "DevOps.SprintData";
        public const string Table_DevOpsEmployees = "DevOps.Employees";
        public const string Table_DevOpsSprints = "DevOps.Sprints";
        public const string Table_DevOpsWorkItems = "DevOps.WorkItems";
        public const string Table_DevOpsWorkItemTask = "DevOps.WorkItemTask";
        public const string Table_DevOpsWorkItemTaskHistory = "DevOps.WorkItemTaskHistory";
    }
}
