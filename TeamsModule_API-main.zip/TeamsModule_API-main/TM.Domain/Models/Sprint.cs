﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TM.Domain.Models
{
    public class Sprint
    {
        [Key]
        public Guid SprintUID { get; set; } = Guid.NewGuid();
        public DateTime CreatedDate { get; set; }
        public string? SprintNumber { get; set; }
        public string? SprintName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
