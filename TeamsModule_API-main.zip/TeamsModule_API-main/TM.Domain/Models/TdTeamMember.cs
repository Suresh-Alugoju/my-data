﻿using System;
using System.Collections.Generic;

namespace TM.Domain.Models
{
    public partial class TdTeamMember
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? PhoneNo { get; set; }
        public int? TeamModuleId { get; set; }
        public int? EmpId { get; set; }
        public int? Status { get; set; }
        public DateTime? JoiningDate { get; set; }
        public DateTime? BillingDate { get; set; }
        public DateTime? RelievingDate { get; set; }
        public string? TechStack { get; set; }

        
    }
}
