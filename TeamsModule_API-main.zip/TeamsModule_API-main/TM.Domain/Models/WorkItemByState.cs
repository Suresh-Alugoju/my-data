﻿using System.ComponentModel.DataAnnotations;

namespace TM.Domain.Models
{
    public class WorkItemByState
    {
        public Guid SprintUID { get; set; }
        public DateTime CreatedDate { get; set; }
        public string SprintNumber { get; set; }
        public string SprintName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }

    public class WorkItem
    {
        public int WorkItemId { get; set; }
        public Guid SprintUID { get; set; }
        public string ItemType { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Severity { get; set; }
        public int Priority { get; set; }
        public DateTime CreatedOn { get; set; }
        public int Points { get; set; }
        public string Tags { get; set; }
        public int AssignedTo { get; set; }
        public int ResolvedBy { get; set; }
        public string Status { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime ModDate { get; set; }
    }

    public class WorkItemTask
    {
        public int TaskId { get; set; }
        public int WorkItemId { get; set; }
        public string TaskName { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public float DurationInHrs { get; set; }
        public string Status { get; set; }
        public string Tags { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime ModDate { get; set; }
    }
}
