﻿using System.ComponentModel.DataAnnotations;

namespace TM.Domain.Models
{
    public class WorkItems
    {
        [Key]
        public int WorkItemId { get; set; }
        public string? ItemType { get; set; }
        public string? Status { get; set; }
    }
}
