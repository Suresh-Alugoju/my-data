﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TM.Domain.Models
{
    public partial class TdTeamMemberRemarks
    {
        public int Id { get; set; }
        public int TeamMemberId { get; set; }
        public string Remark { get; set; } = string.Empty;
        public DateTime RemarkDate { get; set; }
        public byte IsActive { get; set; }
    }
}
