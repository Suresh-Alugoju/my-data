﻿using System;
using System.Collections.Generic;

namespace TM.Domain.Models
{
    public partial class TdTeamDetail
    {

        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string? CliLead { get; set; }
        public string? PerLead { get; set; }
        public string? ScrumMaster { get; set; }
        public string? ProjectName { get; set; }
        public int TotalSize { get; set; }
        public int? Status { get; set; }

    }
}
