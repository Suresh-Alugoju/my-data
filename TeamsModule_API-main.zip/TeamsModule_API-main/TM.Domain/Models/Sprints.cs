﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TM.Domain.Models
{
    public class Sprints
    {
        public Guid SprintUID { get; set; }
        public DateTime CreatedDate { get; set; }
        public string? SprintNumber { get; set; }
        public string? SprintName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
