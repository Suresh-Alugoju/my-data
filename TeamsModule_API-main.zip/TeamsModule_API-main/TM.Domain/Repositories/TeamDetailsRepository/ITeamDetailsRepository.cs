﻿using TeamsModule_API.Models;

namespace TM.Domain.Repositories.TeamDetailsRepository
{
    public interface ITeamDetailsRepository
    {
        IEnumerable<TdTeamDetailDTO> GetTdTeamDetails();
        IEnumerable<TdTeamDetailDTO> GetTdTeamDetail(int id);
        int PutTdTeamDetail(int id, TdTeamDetailDTO tdTeamDetaildto);
        int PostTdTeamDetail(TdTeamDetailDTO tdTeamDetaildto);
        int DeleteTdTeamDetail(int id);
        IEnumerable<TdTeamDetailDTO> GetBarchartTd();
    }
}
