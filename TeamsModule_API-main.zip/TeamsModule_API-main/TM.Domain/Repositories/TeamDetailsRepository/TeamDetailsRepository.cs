﻿using SqlKata.Execution;
using TeamsModule_API.DTOs;
using TeamsModule_API.Models;
using TM.Domain.Models;

namespace TM.Domain.Repositories.TeamDetailsRepository
{
    public class TeamDetailsRepository : ITeamDetailsRepository
    {
        private readonly QueryFactory db;

        public TeamDetailsRepository(QueryFactory db)
        {
            this.db = db;
        }
        public IEnumerable<TdTeamDetailDTO> GetTdTeamDetails()
        {
            IEnumerable<TdTeamDetailDTO> teamDetails = null;
            IEnumerable<TdTeamDetailDTO> teamDetails1 = null;

            try
            {
                teamDetails = db.Query("Td_TeamDetails").Get<TdTeamDetailDTO>();
                foreach (var t in teamDetails)
                {
                    teamDetails1 = db.Query("Td_TeamDetails").Join("Td_TeamMembers", "Td_TeamMembers.TeamModuleId", "Td_TeamDetails.Id").Where("Td_TeamDetails.id", t.Id).Get<TdTeamDetailDTO>();
                    t.TdTeamMemberCount = teamDetails1.Count();
                }

            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
            return teamDetails;
        }

        public IEnumerable<TdTeamDetailDTO> GetTdTeamDetail(int id)
        {
            IEnumerable<TdTeamDetailDTO> teamDetails = null;
            try
            {
                teamDetails = db.Query("Td_TeamDetails").Where("Id", id).Get<TdTeamDetailDTO>();

            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
            return teamDetails;

        }

        public int PutTdTeamDetail(int id, TdTeamDetailDTO tdTeamDetaildto)
        {
            int affected = 0;
            try
            {
                tdTeamDetaildto.Id = id;
                affected = db.Query("Td_TeamDetails").Where("Id", id).Update(new
                {
                    tdTeamDetaildto.Name,
                    tdTeamDetaildto.Cli_Lead,
                    tdTeamDetaildto.Per_Lead,
                    tdTeamDetaildto.ScrumMaster,
                    tdTeamDetaildto.Status,
                    tdTeamDetaildto.ProjectName,
                    tdTeamDetaildto.TotalSize,
                });
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }

            return affected;
        }
        public int PostTdTeamDetail(TdTeamDetailDTO tdTeamDetaildto)
        {
            int insertedId = 0;
            try
            {
                insertedId = db.Query("Td_TeamDetails").InsertGetId<int>(new
                {
                    tdTeamDetaildto.Name,
                    tdTeamDetaildto.Cli_Lead,
                    tdTeamDetaildto.Per_Lead,
                    tdTeamDetaildto.ScrumMaster,
                    tdTeamDetaildto.Status,
                    tdTeamDetaildto.ProjectName,
                    tdTeamDetaildto.TotalSize,
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return insertedId;
        }
        public int DeleteTdTeamDetail(int id)
        {
            int affected = 0;
            try
            {
                affected = db.Query("Td_TeamDetails").Where("Id", id).Delete();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return affected;

        }
        public bool TdTeamDetailExists(int id)
        {
            return db.Query("Td_TeamDetails").Where("Id", id).Exists();
        }

        public IEnumerable<TdTeamDetailDTO> GetBarchartTd()
        {
            IEnumerable<TdTeamDetailDTO> teamDetails = null;
            try
            {
                teamDetails = db.Query("Td_TeamDetails").Get<TdTeamDetailDTO>();

            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
            return teamDetails;

        }
    }
}
