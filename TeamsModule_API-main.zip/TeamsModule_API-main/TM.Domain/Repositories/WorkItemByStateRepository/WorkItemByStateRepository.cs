﻿using SqlKata.Execution;
using TM.Domain.Models;
using TM.Domain.Models.Common;

namespace TM.Domain.Repositories.WorkItemByStateRepository
{
    public class WorkItemByStateRepository:IWorkItemByStateRepository
    {
        private readonly QueryFactory db;

        public WorkItemByStateRepository(QueryFactory db)
        {
            this.db = db;
        }
        
        public IEnumerable<WorkItemByState> Get()
        {
            try
            {
                IEnumerable<WorkItemByState> sprint = db.Query(SqlKataCommon.Table_DevOpsSprints).Distinct().Select("SprintUID", "SprintName").Get<WorkItemByState>();
                return sprint;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public IEnumerable<WorkItem>? GetWorkItems()
        {
            IEnumerable<WorkItem> sprintTitle;
            try
            {
                var sprint = db.Query(SqlKataCommon.Table_DevOpsWorkItems).Get<WorkItem>();
                return sprint;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
        
        public List<Object>? GetWorkItemsBySprint(Guid sprintUID, string workItemType)
        {
            try
            {
                var pie = db.Query(SqlKataCommon.Table_DevOpsWorkItems)
                    .Join(SqlKataCommon.Table_DevOpsSprints, j => j.On("DevOps.WorkItems.SprintUID", "DevOps.Sprints.SprintUID"))
                    .Select("DevOps.WorkItems.WorkItemId", "DevOps.WorkItems.ItemType", "DevOps.WorkItems.Title")
                    .Where("DevOps.Sprints.SprintUID", sprintUID)
                    .Where("DevOps.WorkItems.ItemType", workItemType)
                    .Get();

                List<Object> list = new List<Object>();
                list.Add(pie);
                return list;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public List<object>? GetEmployeeWorkItemCountByStatus(Guid SprintUID, string workItemType)
        {
            try
            {
                var workItemsDetails = db.Query(SqlKataCommon.Table_DevOpsEmployees)
                    .Join(SqlKataCommon.Table_DevOpsWorkItems, j => j.On("DevOps.WorkItems.AssignedTo", "DevOps.Employees.EmpId"))
                    .Select("DevOps.Employees.EmpId", "DevOps.Employees.EmpName", "DevOps.Employees.EmpEmail", "DevOps.WorkItems.Status")
                    .Where("DevOps.WorkItems.SprintUID", SprintUID)
                    .Where("DevOps.WorkItems.ItemType", workItemType)
                    .Get();

                var workItemsCount = (from e in workItemsDetails
                                      group e by new
                                      {
                                          e.EmpEmail,
                                          e.EmpName,
                                          e.EmpId
                                      }
                                      into ItemTypeData
                                      select new
                                      {
                                          ItemTypeData.Key.EmpEmail,
                                          ItemTypeData.Key.EmpName,
                                          ItemTypeData.Key.EmpId,
                                          New = ItemTypeData.Count(x => x.Status == "New"),
                                          Active = ItemTypeData.Count(x => x.Status == "Active"),
                                          PRReview = ItemTypeData.Count(x => x.Status == "PR Review"),
                                          Resolved = ItemTypeData.Count(x => x.Status == "Resolved"),
                                          DeliveredToQA = ItemTypeData.Count(x => x.Status == "Delivered To QA"),
                                          Closed = ItemTypeData.Count(x => x.Status == "Closed"),
                                          Removed = ItemTypeData.Count(x => x.Status == "Removed"),
                                          Total = ItemTypeData.Count()
                                      }); ;

                List<object> list = new List<object>();
                list.Add(workItemsCount);
                return list;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

   
        public List<object>? GetEmployeeTaskCountByStatus(Guid SprintUID, string workItemType, string workItemId)
        {
            try
            {
                var TaskDetails = db.Query(SqlKataCommon.Table_DevOpsEmployees)
                    .Join(SqlKataCommon.Table_DevOpsWorkItems, j => j.On("DevOps.WorkItems.AssignedTo", "DevOps.Employees.EmpId"))
                    .Join(SqlKataCommon.Table_DevOpsWorkItemTask, j => j.On("DevOps.WorkItems.WorkItemId", "DevOps.WorkItemTask.WorkItemId"))
                    .Select("DevOps.Employees.EmpName", "DevOps.Employees.EmpEmail", "DevOps.WorkItemTask.Status")
                    .Where("DevOps.WorkItems.SprintUID", SprintUID)
                    .Where("DevOps.WorkItems.ItemType", workItemType)
                    .Where("DevOps.WorkItemTask.WorkItemId", workItemId)
                    .Get();

                var taskCount = (from e in TaskDetails
                                 group e by new
                                 {
                                     e.EmpEmail,
                                     e.EmpName
                                 }
                                 into ItemTypeData
                                 select new
                                 {
                                     ItemTypeData.Key.EmpEmail,
                                     ItemTypeData.Key.EmpName,
                                     New = ItemTypeData.Count(x => x.Status == "New"),
                                     Active = ItemTypeData.Count(x => x.Status == "Active"),
                                     PRReview = ItemTypeData.Count(x => x.Status == "PR Review"),
                                     Resolved = ItemTypeData.Count(x => x.Status == "Resolved"),
                                     DeliveredToQA = ItemTypeData.Count(x => x.Status == "Delivered To QA"),
                                     Closed = ItemTypeData.Count(x => x.Status == "Closed"),
                                     Removed = ItemTypeData.Count(x => x.Status == "Removed"),
                                     Total = ItemTypeData.Count()
                                 });

                List<object> list = new List<object>();
                list.Add(taskCount);
                return list;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public List<Object> GetWorkItemTasksData(int workItemId)
        {
            try
            {
                var pie = db.Query(SqlKataCommon.Table_DevOpsWorkItemTask)
                    .Select("DevOps.WorkItemTask.Status")
                    .SelectRaw("count(DevOps.WorkItemTask.Status) as Count")
                    .Where("DevOps.WorkItemTask.WorkItemId", workItemId)
                    .GroupBy("DevOps.WorkItemTask.Status")
                    .Get();

                List<Object> list = new List<Object>();
                list.Add(pie);
                return list;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

      
        public List<Object> GetData(Guid sprintUID, string workItemType)
        {
            try
            {
                var pie = db.Query(SqlKataCommon.Table_DevOpsWorkItems)
                    .Join(SqlKataCommon.Table_DevOpsSprints, j => j.On("DevOps.WorkItems.SprintUID", "DevOps.Sprints.SprintUID"))
                    .Join(SqlKataCommon.Table_DevOpsEmployees, j => j.On("DevOps.WorkItems.AssignedTo", "DevOps.Employees.EmpId"))
                    .Select("DevOps.WorkItems.Status", "DevOps.WorkItems.ItemType")
                    .SelectRaw("count(DevOps.WorkItems.ItemType) as Count")
                    .Where("DevOps.WorkItems.ItemType", workItemType)
                    .Where("DevOps.Sprints.SprintUID", sprintUID)
                    .GroupBy("DevOps.WorkItems.Status", "DevOps.WorkItems.ItemType")
                    .Get();

                var empName = db.Query(SqlKataCommon.Table_DevOpsEmployees)
                    .Join(SqlKataCommon.Table_DevOpsWorkItems, j => j.On("DevOps.WorkItems.AssignedTo", "DevOps.Employees.EmpId"))
                    .Select("DevOps.Employees.EmpName").Distinct()
                    .Get();

                var status = db.Query(SqlKataCommon.Table_DevOpsWorkItems)
                    .Select("DevOps.WorkItems.Status").Distinct()
                    .Get();


                List<Object> list = new List<Object>();
                list.Add(pie);
                list.Add(empName);
                list.Add(status);
                return list;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public List<dynamic>? GetWorkItemDetails(Guid SprintUID, string workItemType, string empId)
        {
            try
            {
                var workItemsDetails = db.Query(SqlKataCommon.Table_DevOpsEmployees)
                    .Join(SqlKataCommon.Table_DevOpsWorkItems, j => j.On("DevOps.WorkItems.AssignedTo", "DevOps.Employees.EmpId"))
                    .Select("DevOps.WorkItems.WorkItemId", "DevOps.WorkItems.Title", "DevOps.WorkItems.Points", "DevOps.WorkItems.Status")
                    .Where("DevOps.WorkItems.SprintUID", SprintUID)
                    .Where("DevOps.WorkItems.ItemType", workItemType)
                    .Where("DevOps.WorkItems.AssignedTo", empId)
                    .OrderBy("DevOps.WorkItems.Status").Get();

                return workItemsDetails?.ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }


        public List<Object>? getWorkItemTaskDetails(Guid sprintUID, string workItemType, int workItemId)
        {
            try
            {
                var workItemTaskDetails = db.Query(SqlKataCommon.Table_DevOpsWorkItems)
                    .Join(SqlKataCommon.Table_DevOpsSprints, j => j.On("DevOps.WorkItems.SprintUID", "DevOps.Sprints.SprintUID"))
                    .Join(SqlKataCommon.Table_DevOpsWorkItemTask, j => j.On("DevOps.WorkItems.WorkItemId", "DevOps.WorkItemTask.WorkItemId"))
                    .Select("DevOps.WorkItemTask.TaskName", "DevOps.WorkItemTask.DurationInHrs", "DevOps.WorkItemTask.Status")
                    .Where("DevOps.WorkItems.ItemType", workItemType)
                    .Where("DevOps.Sprints.SprintUID", sprintUID)
                    .Where("DevOps.WorkItemTask.WorkItemId", workItemId)
                    .Get();

                List<Object> list = new List<Object>();
                list.Add(workItemTaskDetails);
                return list;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
    }
}
