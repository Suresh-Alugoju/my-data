﻿using SqlKata.Execution;
using TM.Domain.Models;

namespace TM.Domain.Repositories.WorkAnalysisRepository
{
    public interface IWorkAnalysisRepository
    {
        List<dynamic> GetUserStoryAnalysis(SelectedSprintAndEmployees selectedData);
        List<dynamic> GetBugsAnalysis(SelectedSprintAndEmployees selectedData);
    }
}
