﻿using Microsoft.Extensions.Configuration;
using SqlKata.Execution;
using TM.Domain.Models;
using TM.Domain.Models.Common;

namespace TM.Domain.Repositories.WorkAnalysisRepository
{
    public class WorkAnalysisRepository:IWorkAnalysisRepository
    {
        private readonly QueryFactory db;
        static string sprints = SqlKataCommon.Table_DevOpsSprints;
        static string workItems = SqlKataCommon.Table_DevOpsWorkItems;
        static string employees = SqlKataCommon.Table_DevOpsEmployees;

        public WorkAnalysisRepository(QueryFactory db)
        {
            this.db = db;
        }

        public List<dynamic> GetUserStoryAnalysis(SelectedSprintAndEmployees selectedData)
        {
            List<string>? sprintUIDs = selectedData.SprintUIDs?.ToList();
            List<int>? team1EmployeeIds = selectedData.Team1EmployeeIds?.ToList();
            List<int>? team2EmployeeIds = selectedData.Team2EmployeeIds?.ToList();

            var sprintDetails = GetSprintDetailsWithTeamSize(db, sprintUIDs);

            var result1 = GetUserStoryAnalysisForEmployees(db, sprintUIDs, team1EmployeeIds);
            var result2 = GetUserStoryAnalysisForEmployees(db, sprintUIDs, team2EmployeeIds);

            List<dynamic> result = new List<dynamic>();
            for (int i = 0; i < sprintUIDs?.Count; i++)
            {
                dynamic workAnalysis = new System.Dynamic.ExpandoObject();
                workAnalysis.SprintUID = sprintUIDs[i];

                var currentSprint = sprintDetails.FirstOrDefault(x => x.SprintUID.ToString().ToLower().Equals(sprintUIDs[i].ToString().ToLower()));
                workAnalysis.SprintName = currentSprint?.SprintName;
                workAnalysis.SprintNumber = currentSprint?.SprintNumber;
                workAnalysis.TeamSize = currentSprint?.TeamSize;

                var team1Result = result1.FirstOrDefault(x => x.SprintUID.ToString().ToLower().Equals(sprintUIDs[i].ToString().ToLower()));
                var team2Result = result2.FirstOrDefault(x => x.SprintUID.ToString().ToLower().Equals(sprintUIDs[i].ToString().ToLower()));

                workAnalysis.Team1 = (team1Result == null) ? 0 : team1Result.StoryPoints;
                workAnalysis.Team2 = (team2Result == null) ? 0 : team2Result.StoryPoints;

                result.Add(workAnalysis);
            }

            return result;
        }

        public List<dynamic> GetBugsAnalysis(SelectedSprintAndEmployees selectedData)
        {
            List<string>? sprintUIDs = selectedData.SprintUIDs?.ToList();
            List<int>? team1EmployeeIds = selectedData.Team1EmployeeIds?.ToList();
            List<int>? team2EmployeeIds = selectedData.Team2EmployeeIds?.ToList();

            
            var sprintDetails = GetSprintDetailsWithTeamSize(db, sprintUIDs);

            var result1 = GetBugsAnalysisForEmployees(db, sprintUIDs, team1EmployeeIds);
            var result2 = GetBugsAnalysisForEmployees(db, sprintUIDs, team2EmployeeIds);

            List<dynamic> result = new List<dynamic>();
            for (int i = 0; i < sprintUIDs.Count; i++)
            {
                dynamic workAnalysis = new System.Dynamic.ExpandoObject();
                workAnalysis.SprintUID = sprintUIDs[i];

                var currentSprint = sprintDetails.FirstOrDefault(x => x.SprintUID.ToString().ToLower().Equals(sprintUIDs[i].ToString().ToLower()));
                workAnalysis.SprintName = currentSprint?.SprintName;
                workAnalysis.SprintNumber = currentSprint?.SprintNumber;
                workAnalysis.TeamSize = currentSprint?.TeamSize;

                var team1Result = result1.FirstOrDefault(x => x.SprintUID.ToString().ToLower().Equals(sprintUIDs[i].ToString().ToLower()));
                var team2Result = result2.FirstOrDefault(x => x.SprintUID.ToString().ToLower().Equals(sprintUIDs[i].ToString().ToLower()));

                workAnalysis.Team1 = (team1Result == null) ? 0 : team1Result.BugCount;
                workAnalysis.Team2 = (team2Result == null) ? 0 : team2Result.BugCount;

                result.Add(workAnalysis);
            }

            return result;
        }

        List<dynamic> GetSprintDetailsWithTeamSize(QueryFactory db, List<string>? sprintUIDs)
        {

            {
                var teamSize = db.Query(sprints)
                    .Join(workItems, x => x.On(workItems + ".SprintUID", sprints + ".SprintUID"))
                    .Join(employees, x => x.On(employees + ".EmpId", workItems + ".ResolvedBy"))
                    .WhereIn(sprints + ".SprintUID", sprintUIDs)
                    .Select("DevOps.Sprints.SprintUID")
                    .SelectRaw($"COUNT(distinct {employees}.EmpId) TeamSize")
                    .GroupBy("DevOps.Sprints.SprintUID");

                var sprintDetails = db.Query(sprints)
                    .LeftJoin(teamSize.As("T"), x => x.On("T.SprintUID", sprints + ".SprintUID"))
                    .WhereIn(sprints + ".SprintUID", sprintUIDs)
                    .Select("DevOps.Sprints.SprintUID", "DevOps.Sprints.SprintName", "DevOps.Sprints.SprintNumber")
                    .SelectRaw("ISNULL(T.TeamSize, 0) TeamSize")
                    .OrderBy("DevOps.Sprints.SprintNumber").Get<dynamic>();

                return sprintDetails.ToList();
            }
        }

        List<dynamic> GetUserStoryAnalysisForEmployees(QueryFactory db, List<string>? sprintUIDs, List<int>? employeeIds)
        {

            {
                var result = db.Query(sprints)
                    .Join(workItems, x => x.On(workItems + ".SprintUID", sprints + ".SprintUID"))
                    .Join(employees, x => x.On(employees + ".EmpId", workItems + ".ResolvedBy"))
                    .WhereIn(sprints + ".SprintUID", sprintUIDs)
                    .Where(workItems + ".ItemType", "User Story").Where(workItems + ".Status", "Closed")
                    .WhereIn(employees + ".EmpId", employeeIds)
                    .Select("DevOps.Sprints.SprintUID")
                    .SelectRaw($"SUM(ISNULL(DevOps.WorkItems.Points, 0)) StoryPoints")
                    .GroupBy("DevOps.Sprints.SprintUID")
                    .Get<dynamic>();

                return result.ToList();
            }
        }

        List<dynamic> GetBugsAnalysisForEmployees(QueryFactory db, List<string>? sprintUIDs, List<int>? employeeIds)
        {

            {
                var result = db.Query(sprints)
                    .Join(workItems, x => x.On(workItems + ".SprintUID", sprints + ".SprintUID"))
                    .Join(employees, x => x.On(employees + ".EmpId", workItems + ".ResolvedBy"))
                    .WhereIn(sprints + ".SprintUID", sprintUIDs)
                    .Where(workItems + ".ItemType", "Bug").Where(workItems + ".Status", "Closed")
                    .WhereIn(employees + ".EmpId", employeeIds)
                    .Select("DevOps.Sprints.SprintUID")
                    .SelectRaw($"COUNT({employees}.EmpId) as BugCount")
                    .GroupBy("DevOps.Sprints.SprintUID")
                    .Get<dynamic>();

                return result.ToList();
            }
        }
    }

}
