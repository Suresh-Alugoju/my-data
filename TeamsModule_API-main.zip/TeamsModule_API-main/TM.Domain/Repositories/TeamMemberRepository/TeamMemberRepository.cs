﻿using SqlKata.Execution;
using TeamsModule_API.DTOs;
using TM.Domain.Repositories.TeamMemberRepository;

namespace TM.Domain.Repositories.TeamDetailsRepository
{
    public class TeamMemberRepository : ITeamMemberRepository
    {
        private readonly QueryFactory db;

        public TeamMemberRepository(QueryFactory db)
        {
            this.db = db;
        }

        public IEnumerable<TdTeamMemberDTO> GetTdTeamMembers()
        {
            IEnumerable<TdTeamMemberDTO> teamMembers = null;
            try
            {
                //teamMembers = db.Query("Td_TeamMembers").Get<TdTeamMem berDTO>();
                teamMembers = db.Query("Td_TeamMembers").Join("Td_TeamDetails", "Td_TeamDetails.Id", "Td_TeamMembers.TeamModuleId")
                    .Select("Td_TeamMembers.Id", "Td_TeamMembers.Name",
                    "Td_TeamMembers.Email",
                    "Td_TeamMembers.PhoneNo",
                    "Td_TeamMembers.TeamModuleId",
                    "Td_TeamMembers.EmpId",
                    "Td_TeamMembers.Status",
                    "Td_TeamMembers.JoiningDate",
                    "Td_TeamMembers.BillingDate",
                    "Td_TeamMembers.RelievingDate",
                     "Td_TeamMembers.TechStack",
                               "Td_TeamDetails.Name as TeamName",
                               "Td_TeamDetails.Cli_Lead").Get<TdTeamMemberDTO>();

            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
            return teamMembers;

        }
        public IEnumerable<TdTeamMemberDTO> GetTdTeamMember(int id)
        {
            IEnumerable<TdTeamMemberDTO> teamMembers = null;
            try
            {
                //  teamMembers = db.Query("Td_TeamMembers").Where("Id", id).Get<TdTeamMemberDTO>();
                teamMembers = db.Query("Td_TeamMembers").Join("Td_TeamDetails", "Td_TeamDetails.Id", "Td_TeamMembers.TeamModuleId")
                      .Select("Td_TeamMembers.Id", "Td_TeamMembers.Name",
                      "Td_TeamMembers.Email",
                      "Td_TeamMembers.PhoneNo",
                      "Td_TeamMembers.TeamModuleId",
                      "Td_TeamMembers.EmpId",
                      "Td_TeamMembers.Status",
                      "Td_TeamMembers.JoiningDate",
                      "Td_TeamMembers.BillingDate",
                      "Td_TeamMembers.RelievingDate",
                       "Td_TeamMembers.TechStack",
                                 "Td_TeamDetails.Name as TeamName",
                                 "Td_TeamDetails.Cli_Lead").Where("Td_TeamMembers.Id", id).Get<TdTeamMemberDTO>();

            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
            return teamMembers;

        }

        public int PutTdTeamMember(int id, TdTeamMemberDTO tdTeamMemberdto)
        {
            int affected = 0;
            try
            {
                tdTeamMemberdto.Id = id;
                affected = db.Query("Td_TeamMembers").Where("Id", id).Update(new
                {
                    tdTeamMemberdto.Name,
                    tdTeamMemberdto.Email,
                    tdTeamMemberdto.PhoneNo,
                    tdTeamMemberdto.TeamModuleId,
                    tdTeamMemberdto.EmpId,
                    tdTeamMemberdto.Status,
                    tdTeamMemberdto.JoiningDate,
                    tdTeamMemberdto.BillingDate,
                    tdTeamMemberdto.RelievingDate,
                    tdTeamMemberdto.TechStack
                    //,tdTeamMemberdto.ReportingTo
                });
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }

            return affected;
        }

        public int PostTdTeamMember(TdTeamMemberDTO tdTeamMemberdto)
        {
            int insertedId = 0;
            try
            {
                insertedId = db.Query("Td_TeamMembers").InsertGetId<int>(new
                {
                    tdTeamMemberdto.Name,
                    tdTeamMemberdto.Email,
                    tdTeamMemberdto.PhoneNo,
                    tdTeamMemberdto.TeamModuleId,
                    tdTeamMemberdto.EmpId,
                    tdTeamMemberdto.Status,
                    tdTeamMemberdto.JoiningDate,
                    tdTeamMemberdto.BillingDate,
                    tdTeamMemberdto.RelievingDate,
                    tdTeamMemberdto.TechStack
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return insertedId;
        }
        public int DeleteTdTeamMember(int id)
        {
            int affected = 0;
            try
            {
                affected = db.Query("Td_TeamMembers").Where("Id", id).Delete();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return affected;
        }
        public bool TdTeamMemberExists(int id)
        {
            return db.Query("Td_TeamMembers").Where("Id", id).Exists();
        }
        public IEnumerable<TempDTO> GetTdTeamMembersBasedOnSkills()
        {
            IEnumerable<TempDTO> teamMembers = null;
            try
            {
                //teamMembers = db.Query("Td_TeamMembers").Get<TdTeamMem berDTO>();
                teamMembers = db.Query("Td_TeamMembers").Select("TechStack").SelectRaw("count(*) as count").GroupBy("TechStack").Get<TempDTO>();
                //var countQuery = db.Query("")
                //teamMembers = db.Query("Td_TeamMembers").Join("Td_TeamDetails", "Td_TeamDetails.Id", "Td_TeamMembers.TeamModuleId").Select count(Select(Td_TeamMembers.TechStack) from[Td_TeamMembers])Get<TempDTO>();
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
            return teamMembers;
        }

  }
}
