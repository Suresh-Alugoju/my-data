﻿using System.Runtime.InteropServices;
using TeamsModule_API.DTOs;

namespace TM.Domain.Repositories.TeamMemberRepository
{
    public interface ITeamMemberRepository
    {
        IEnumerable<TdTeamMemberDTO> GetTdTeamMembers();
        IEnumerable<TdTeamMemberDTO> GetTdTeamMember(int id);
        int PutTdTeamMember(int id, TdTeamMemberDTO tdTeamMemberdto);
        int PostTdTeamMember(TdTeamMemberDTO tdTeamMemberdto);
        int DeleteTdTeamMember(int id);
        IEnumerable<TempDTO> GetTdTeamMembersBasedOnSkills();

    }

}
