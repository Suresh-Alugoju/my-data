﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeamsModule_API.Models;
using TM.Domain.Models;

namespace TM.Domain.Repositories.SprintDataRepository
{
    public interface ISprintDataRepository
    {
        IEnumerable<SprintData> Get();
        int Upsert(SprintData sprintData);
        int UpsertSprint(Sprint sprint);
    }
}
