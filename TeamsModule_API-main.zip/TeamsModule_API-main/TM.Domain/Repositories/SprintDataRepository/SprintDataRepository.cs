﻿using SqlKata.Execution;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Dto;
using TM.Domain.Models;
using TM.Domain.Models.Common;

namespace TM.Domain.Repositories.SprintDataRepository
{
    public class SprintDataRepository : ISprintDataRepository
    {
        private readonly QueryFactory db;

        public SprintDataRepository(QueryFactory db)
        {
            this.db = db;
        }
        public IEnumerable<SprintData> Get()
        {
           
            IEnumerable<SprintData> sprintData = db.Query(SqlKataCommon.Table_DevOpsSprintData).Get<SprintData>();
            return sprintData;
        }
        public int Upsert(SprintData sprintData)
        {
            int insertedId = 0;
            insertedId = db.Query(SqlKataCommon.Table_DevOpsSprintData).Insert(sprintData);
            return insertedId;
        }
        public int UpsertSprint(Sprint sprint)
        {
            int insertedId = 0;
            insertedId = db.Query(SqlKataCommon.Table_DevOpsSprints).Insert(sprint);
            return insertedId;
        }

    }
}
