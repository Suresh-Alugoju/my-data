﻿using SqlKata.Execution;
using TeamsModule_API.Models;
using TM.Domain.Models;
using System.Web;
using System.Runtime.InteropServices;


namespace TM.Domain.Repositories.WorkStatusRepository
{
    public class WorkStatusRepository : IWorkStatusRepository
    {
        private readonly QueryFactory db;

        public WorkStatusRepository(QueryFactory db)
        {
            this.db = db;
        }
       
        public IEnumerable<dynamic> GetStatusCountData(List<string> sprintUIDs)
        {
            try
            {
             
                var WorkItemDetails = db.Query("DevOps.Sprints")
                      .Join("DevOps.WorkItems", j => j.On("DevOps.WorkItems.SprintUID", "DevOps.Sprints.SprintUID"))
                      .WhereIn("DevOps.Sprints.sprintUID", sprintUIDs)
                      .Select("ItemType", "DevOps.WorkItems.Status").Get();

                var workItemsCountByStatus = (from num in WorkItemDetails
                                              group num by num.ItemType into ItemTypeData
                                              select new
                                              {
                                                  ItemType = ItemTypeData.Key,
                                                  New = ItemTypeData.Count(x => x.Status == "New"),
                                                  Active = ItemTypeData.Count(x => x.Status == "Active"),
                                                  PRReview = ItemTypeData.Count(x => x.Status == "PR Review"),
                                                  Resolved = ItemTypeData.Count(x => x.Status == "Resolved"),
                                                  DeliveredToQA = ItemTypeData.Count(x => x.Status == "Delivered To QA"),
                                                  Closed = ItemTypeData.Count(x => x.Status == "Closed"),
                                                  Removed = ItemTypeData.Count(x => x.Status == "Removed"),
                                                  Total = ItemTypeData.Count(x => x.ItemType == ItemTypeData.Key)
                                              });


                var WorkCount = db.Query("DevOps.Sprints")
                    .Join("DevOps.WorkItems", j => j.On("DevOps.WorkItems.SprintUID", "DevOps.Sprints.SprintUID"))
                    .WhereIn("DevOps.Sprints.sprintUID", sprintUIDs)
                    .SelectRaw("Count(WorkItems.Status) as TotalCount").Get();

                var totalCountsByWorkItems = (from wcount in WorkItemDetails
                                              group wcount by wcount.status into ItemTypeData
                                              select new
                                              {

                                                  New = ItemTypeData.Count(x => x.Status == "New"),
                                                  Active = ItemTypeData.Count(x => x.Status == "Active"),
                                                  PRReview = ItemTypeData.Count(x => x.Status == "PR Review"),
                                                  Resolved = ItemTypeData.Count(x => x.Status == "Resolved"),
                                                  DeliveredToQA = ItemTypeData.Count(x => x.Status == "Delivered To QA"),
                                                  Closed = ItemTypeData.Count(x => x.Status == "Closed"),
                                                  Removed = ItemTypeData.Count(x => x.Status == "Removed"),
                                                  Total = ItemTypeData.Count()
                                              });


                List<object> list = new List<object>
                {
                    workItemsCountByStatus,
                    totalCountsByWorkItems
                };

                return list;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
               return null;
            }

        }

        public IEnumerable<dynamic> GetBugSeverityCount(List<string> sprintUIDs)
        {
            try
            {
               
                IEnumerable<dynamic> severityCount = db.Query("DevOps.WorkItems")
                    .Join("DevOps.Sprints", j => j.On("DevOps.WorkItems.SprintUID", "DevOps.Sprints.SprintUID"))
                     .Select("DevOps.WorkItems.Severity", "DevOps.Sprints.SprintNumber")
                     .Where("DevOps.WorkItems.ItemType", "Bug")
                     .WhereIn("DevOps.WorkItems.sprintUID", sprintUIDs)
                     .OrderBy("DevOps.Sprints.SprintNumber")
                     .Get<dynamic>();

                var workItemsCountSeverity = (from num in severityCount
                                              group num by num.SprintNumber into ItemSeverity

                                              select new
                                              {
                                                  SprintNumber = ItemSeverity.Key,
                                                  Critical = ItemSeverity.Count(x => x.Severity == "1 - Critical"),
                                                  High = ItemSeverity.Count(x => x.Severity == "2 - High"),
                                                  Medium = ItemSeverity.Count(x => x.Severity == "3 - Medium"),
                                                  Low = ItemSeverity.Count(x => x.Severity == "4 - Low"),
                                              });
                return workItemsCountSeverity;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }

        }


        public IEnumerable<dynamic> GetUserStoryPointsCount(List<string> sprintUIDs)
        {
            try
            {
               
                IEnumerable<dynamic> PointsCount = db.Query("DevOps.WorkItems")
                    .Join("DevOps.Sprints", j => j.On("DevOps.WorkItems.SprintUID", "DevOps.Sprints.SprintUID"))
                     .Select("DevOps.WorkItems.Points", "DevOps.WorkItems.WorkItemId", "DevOps.Sprints.SprintNumber")
                     .Where("DevOps.WorkItems.ItemType", "User Story")
                     .WhereIn("DevOps.WorkItems.sprintUID", sprintUIDs)
                     .OrderBy("DevOps.Sprints.SprintNumber")
                     .Get<dynamic>();
                var workItemsPointsCount = (from num in PointsCount
                                            group num by num.SprintNumber into ItemSeverity

                                            select new
                                            {
                                                SprintNumber = ItemSeverity.Key,
                                                Low = ItemSeverity.Count(x => x.Points >= 0 && x.Points <= 3),
                                                Medium = ItemSeverity.Count(x => x.Points >= 4 && x.Points < 8),
                                                High = ItemSeverity.Count(x => x.Points >= 8),
                                            });
                return workItemsPointsCount;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }

        }
    }
}
