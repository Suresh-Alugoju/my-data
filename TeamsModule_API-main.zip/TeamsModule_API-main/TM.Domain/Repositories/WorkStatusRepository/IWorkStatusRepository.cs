﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeamsModule_API.Models;
using TM.Domain.Models;

namespace TM.Domain.Repositories.WorkStatusRepository
{
    public interface IWorkStatusRepository
    {
       // IEnumerable<Sprints> Get();
        IEnumerable<dynamic> GetStatusCountData(List<string> sprintUIDs);
        IEnumerable<dynamic> GetBugSeverityCount(List<string> sprintUIDs);
        IEnumerable<dynamic> GetUserStoryPointsCount(List<string> sprintUIDs);
    }
}
