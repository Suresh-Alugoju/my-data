﻿using System.Runtime.InteropServices;
using SqlKata.Execution;
using TM.Domain.Dto;
using TM.Domain.Models;
using TM.Domain.Models.Common;

namespace TM.Domain.Repositories.PerformanceRepository
{
    public class PerformanceRepository : IPerformanceRepository
    {
        private readonly QueryFactory db;

        public PerformanceRepository(QueryFactory db)
        {
            this.db = db;
        }
        public IEnumerable<dynamic> GetCompletedTasks(int EmpId)
        {
            IEnumerable<dynamic> sprintData = db.Query(SqlKataCommon.Table_DevOpsWorkItemTaskHistory)
                .Join(SqlKataCommon.Table_DevOpsWorkItemTask, SqlKataCommon.Table_DevOpsWorkItemTaskHistory + ".TaskId",
                SqlKataCommon.Table_DevOpsWorkItemTask + ".TaskId")
                .Where("EmpId", EmpId)
                .Where(SqlKataCommon.Table_DevOpsWorkItemTaskHistory + ".Status", "Closed")
                .SelectRaw(SqlKataCommon.Table_DevOpsWorkItemTaskHistory + ".CreatedDate as ModDate").SelectRaw("Count(*) as count")
                .GroupBy(SqlKataCommon.Table_DevOpsWorkItemTaskHistory + ".CreatedDate").Get<dynamic>();
            return sprintData;
        }
        public IEnumerable<dynamic> GetRemainingTasks(int EmpId)
        {
            IEnumerable<dynamic> sprintData = db.Query(SqlKataCommon.Table_DevOpsWorkItemTaskHistory)
                .Join(SqlKataCommon.Table_DevOpsWorkItemTask, SqlKataCommon.Table_DevOpsWorkItemTaskHistory + ".TaskId",
                SqlKataCommon.Table_DevOpsWorkItemTask + ".TaskId")
                .Where("EmpId", EmpId)
                .WhereNot(SqlKataCommon.Table_DevOpsWorkItemTaskHistory + ".Status", "Closed")
                .SelectRaw(SqlKataCommon.Table_DevOpsWorkItemTaskHistory + ".CreatedDate as ModDate").SelectRaw("Count(*) as count")
                .GroupBy(SqlKataCommon.Table_DevOpsWorkItemTaskHistory + ".CreatedDate").Get<dynamic>();
            return sprintData;
        }
        public IEnumerable<dynamic> GetAllEmployees()
        {
            IEnumerable<dynamic> employees = db.Query(SqlKataCommon.Table_DevOpsEmployees).Select("EmpId", "EmpName", "EmpEmail")
                .Get<dynamic>();
            return employees;
        }
        public IEnumerable<dynamic> GetSprintPlannedHr(Sprint[] sprintsList)
        {
            var temp = sprintsList.Select(x => x.SprintUID).ToArray();
            IEnumerable<dynamic> planned = db.Query(SqlKataCommon.Table_DevOpsSprints)
                .Join(SqlKataCommon.Table_DevOpsWorkItems, SqlKataCommon.Table_DevOpsSprints + ".SprintUID",
                SqlKataCommon.Table_DevOpsWorkItems + ".SprintUID").Select(SqlKataCommon.Table_DevOpsSprints + ".SprintNumber")
                .SelectRaw("Ceiling(SUM(" + SqlKataCommon.Table_DevOpsWorkItems + ".Points)*6.5) as Hr")
                .WhereIn(SqlKataCommon.Table_DevOpsSprints + ".SprintUID", temp)
                .GroupBy(SqlKataCommon.Table_DevOpsSprints + ".SprintNumber").Get<dynamic>();
            return planned;

        }
        public IEnumerable<dynamic> GetSprintActualHr(Sprint[] sprintsList)
        {
            var temp = sprintsList.Select(x => x.SprintUID).ToArray();
            IEnumerable<dynamic> planned = db.Query(SqlKataCommon.Table_DevOpsSprints).Join(SqlKataCommon.Table_DevOpsWorkItems, SqlKataCommon.Table_DevOpsSprints + ".SprintUID",
                SqlKataCommon.Table_DevOpsWorkItems + ".SprintUID").Join(SqlKataCommon.Table_DevOpsWorkItemTask, SqlKataCommon.Table_DevOpsWorkItems + ".WorkItemId",
                SqlKataCommon.Table_DevOpsWorkItemTask + ".WorkItemId").Select(SqlKataCommon.Table_DevOpsSprints + ".SprintNumber")
                .SelectRaw("SUM(" + SqlKataCommon.Table_DevOpsWorkItemTask + ".DurationInHrs) as Hr")
                .WhereIn(SqlKataCommon.Table_DevOpsSprints + ".SprintUID", temp)
                .GroupBy(SqlKataCommon.Table_DevOpsSprints + ".SprintNumber").Get<dynamic>();
            return planned;
        }
        public IEnumerable<dynamic> GetSprintTotalPoints(Sprint[] sprintsList)
        {
            var temp = sprintsList.Select(x => x.SprintUID).ToArray();
            IEnumerable<dynamic> planned = db.Query(SqlKataCommon.Table_DevOpsSprints)
                .Join(SqlKataCommon.Table_DevOpsWorkItems, SqlKataCommon.Table_DevOpsSprints + ".SprintUID",
                SqlKataCommon.Table_DevOpsWorkItems + ".SprintUID").Select(SqlKataCommon.Table_DevOpsSprints + ".SprintNumber")
                .SelectRaw("SUM(" + SqlKataCommon.Table_DevOpsWorkItems + ".Points) as TotalPoints")
                .WhereIn(SqlKataCommon.Table_DevOpsSprints + ".SprintUID", temp)
                .GroupBy(SqlKataCommon.Table_DevOpsSprints + ".SprintNumber").Get<dynamic>();
            return planned;

        }
        public IEnumerable<dynamic> GetSprintRemainingEfforts(Sprint[] sprintsList)
        {
            var temp = sprintsList.Select(x => x.SprintUID).ToArray();
            IEnumerable<dynamic> planned = db.Query(SqlKataCommon.Table_DevOpsSprints).Join(SqlKataCommon.Table_DevOpsWorkItems, SqlKataCommon.Table_DevOpsSprints + ".SprintUID",
                SqlKataCommon.Table_DevOpsWorkItems + ".SprintUID").Select(SqlKataCommon.Table_DevOpsSprints + ".SprintNumber")
                .SelectRaw("SUM(" + SqlKataCommon.Table_DevOpsWorkItems + ".Points)*6.5 as Hr")
                .WhereNot(SqlKataCommon.Table_DevOpsWorkItems + ".Status", "Closed")
                .WhereIn(SqlKataCommon.Table_DevOpsSprints + ".SprintUID", temp)
                .GroupBy(SqlKataCommon.Table_DevOpsSprints + ".SprintNumber").Get<dynamic>();
            return planned;

        }

      
        public dynamic GetEmployeeRemainingEffort(int empId,  string strDate,  string endDate)
        {
            var planned = db.Query(SqlKataCommon.Table_DevOpsWorkItemTaskHistory)
                .Join(SqlKataCommon.Table_DevOpsWorkItemTask, SqlKataCommon.Table_DevOpsWorkItemTaskHistory + ".TaskId",
                SqlKataCommon.Table_DevOpsWorkItemTask + ".TaskId")
                .Join(SqlKataCommon.Table_DevOpsWorkItems, SqlKataCommon.Table_DevOpsWorkItemTask + ".WorkItemId",
                SqlKataCommon.Table_DevOpsWorkItems + ".WorkItemId")
                .SelectRaw(SqlKataCommon.Table_DevOpsWorkItemTaskHistory + ".CreatedDate as ModDate")
                .SelectRaw("(SUM(Points)*6.5)-Sum(DurationInHrs) as count")
                .Where(SqlKataCommon.Table_DevOpsWorkItemTaskHistory + ".Status", "Closed")
                .Where(SqlKataCommon.Table_DevOpsWorkItems + ".ItemType", "User Story")
                .Where(SqlKataCommon.Table_DevOpsWorkItemTask + ".EmpId", empId)
                .WhereBetween(SqlKataCommon.Table_DevOpsWorkItemTaskHistory + ".CreatedDate", strDate, endDate)
                .GroupBy(SqlKataCommon.Table_DevOpsWorkItemTaskHistory + ".CreatedDate")
                .Get<dynamic>();
            return planned;
        }
        public dynamic GetEmployeeTotalHour(int empId, string strDate, string endDate)
        {
            dynamic planned = db.Query(SqlKataCommon.Table_DevOpsWorkItems)
                .SelectRaw("CEILING(SUM(" + SqlKataCommon.Table_DevOpsWorkItems + ".Points))*6.5 as TotalHours")
                .Where(SqlKataCommon.Table_DevOpsWorkItems + ".AssignedTo", empId)
                .WhereRaw("Cast(" + SqlKataCommon.Table_DevOpsWorkItems + ".ModDate as date) between "
                + "'" + strDate + "' and '" + endDate + "'"
                )
                .Get<dynamic>();
            return planned;
        }
        public dynamic GetCurrentSprint()
        {
            dynamic currentSprint = db.Query(SqlKataCommon.Table_DevOpsSprints).
            Select("SprintUID as sprintUID", "SprintNumber as sprintNumber", "SprintName as sprintName",
                "CreatedDate as createdDate", "StartDate as startDate", "EndDate as endDate")
            .SelectRaw("DATEDIFF(day, GETDATE(), EndDate) as daysLeft")
            .OrderByDesc("EndDate", "CreatedDate").Take(1)
            .Get<dynamic>().Single();

            return currentSprint;
        }
        public dynamic GetCurrentSprintWorkItemCount(string sprintUID)
        {
            dynamic workItemCount = new System.Dynamic.ExpandoObject();
            workItemCount.UserStoryCount = db.Query(SqlKataCommon.Table_DevOpsWorkItems)
                .SelectRaw("Count(*) as WorkItemCount")
                .Where("SprintUID", sprintUID.ToString()).Where("ItemType", "User Story").Get().Single();

            workItemCount.BugsCount = db.Query(SqlKataCommon.Table_DevOpsWorkItems)
                .SelectRaw("Count(*) as WorkItemCount")
                .Where("SprintUID", sprintUID.ToString()).Where("ItemType", "Bug").Get().Single();

            return workItemCount;
        }
        public dynamic GetDeviatedWorkItems(Sprint[] sprintsList)
        {
            var sprints = sprintsList.Select(x => x.SprintUID).ToArray();
            var temp = db.Query(SqlKataCommon.Table_DevOpsWorkItems)
            .Join(SqlKataCommon.Table_DevOpsWorkItemTask,
            SqlKataCommon.Table_DevOpsWorkItemTask + ".WorkItemId",
            SqlKataCommon.Table_DevOpsWorkItems + ".WorkItemId")
            .Select(SqlKataCommon.Table_DevOpsWorkItems + ".WorkItemId")
            .SelectRaw("SUM(" + SqlKataCommon.Table_DevOpsWorkItemTask + ".DurationInHrs) as ActualHour")
            .GroupBy(SqlKataCommon.Table_DevOpsWorkItems + ".WorkItemId")
            ;
            var query = db.Query(SqlKataCommon.Table_DevOpsWorkItems)
            .With("temp", temp)
            .Join("temp",
            "temp" + ".WorkItemId",
            SqlKataCommon.Table_DevOpsWorkItems + ".WorkItemId"
            ).Join(SqlKataCommon.Table_DevOpsSprints,
            SqlKataCommon.Table_DevOpsWorkItems + ".SprintUID",
            SqlKataCommon.Table_DevOpsSprints + ".SprintUID"
            ).Join(SqlKataCommon.Table_DevOpsEmployees,
            SqlKataCommon.Table_DevOpsEmployees + ".EmpId",
            SqlKataCommon.Table_DevOpsWorkItems + ".ResolvedBy"
            )
            .Select("temp.WorkItemId", "temp.ActualHour", SqlKataCommon.Table_DevOpsEmployees + ".EmpName",
            SqlKataCommon.Table_DevOpsWorkItems + ".Title")
            .SelectRaw(SqlKataCommon.Table_DevOpsWorkItems + ".Points*6.5 as ExpectedHour")
            .Select(SqlKataCommon.Table_DevOpsSprints + ".SprintName")
            .WhereIn(SqlKataCommon.Table_DevOpsSprints + ".SprintUID", sprints)
            .OrderBy(SqlKataCommon.Table_DevOpsSprints + ".SprintName")
            .Get<dynamic>();
            return query;
        }
    }
}
