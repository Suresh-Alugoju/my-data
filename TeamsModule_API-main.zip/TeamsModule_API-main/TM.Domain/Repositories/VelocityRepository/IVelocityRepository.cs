﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SqlKata.Execution;

namespace TM.Domain.Repositories.VelocityRepository
{
    public interface IVelocityRepository
    {
        List<dynamic> GetSprintVelocityDetails(List<string> sprintUIDs);
        IEnumerable<dynamic> GetSprintWorkItemsCountByStatus(List<string> sprintUIDs);
    }
}
