﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using SqlKata.Execution;
using SqlKata;
using TM.Domain.Models.Common;

namespace TM.Domain.Repositories.VelocityRepository
{
    public class VelocityRepository:IVelocityRepository
    {
        private readonly QueryFactory db;
        static string sprints = SqlKataCommon.Table_DevOpsSprints;
        static string workItems = SqlKataCommon.Table_DevOpsWorkItems;

        public VelocityRepository(QueryFactory db)
        {
            this.db = db;

        }


        public List<dynamic> GetSprintVelocityDetails(List<string> sprintUIDs)
        {
            

            var distinctSprints = db.Query(sprints)
                .Select("SprintNumber").SelectRaw("MAX(CreatedDate) as CreatedDate")
                .GroupBy("SprintNumber");

            var query = db.Query(sprints)
                .Join(distinctSprints.As("B"), x => x.On(sprints + ".SprintNumber", "B.SprintNumber")
                                                    .On(sprints + ".CreatedDate", "B.CreatedDate"))
                .LeftJoin(workItems, x => x.On(sprints + ".SprintUID", workItems + ".SprintUID")
                                                                    .Where(workItems + ".Status", "Closed"))
                .Select(sprints + ".SprintUID", sprints + ".SprintNumber", sprints + ".SprintName")
                .SelectRaw($"ISNULL(SUM({workItems}.Points), 0) TotalPoints");

            if (sprintUIDs.Count > 0)
                query = query.WhereIn(sprints + ".SprintUID", sprintUIDs);

            query = query.GroupBy(sprints + ".SprintUID", sprints + ".SprintNumber", sprints + ".SprintName")
               .OrderBy(sprints + ".SprintNumber");

            List<dynamic> distinctEmployees = GetEmployeeCountPerSprint(db, sprintUIDs);

            List<dynamic> totalPointsPerStory = query.Get<dynamic>().ToList();
            List<dynamic> sprintVelocityDetails = new List<dynamic>();
            for (int i = 0; i < totalPointsPerStory.Count(); i++)
            {
                dynamic sprintVelocity = new System.Dynamic.ExpandoObject();
                sprintVelocity.SprintUID = totalPointsPerStory[i].SprintUID;
                sprintVelocity.SprintNumber = totalPointsPerStory[i].SprintNumber;
                sprintVelocity.SprintName = totalPointsPerStory[i].SprintName;
                sprintVelocity.TotalPoints = totalPointsPerStory[i].TotalPoints;
                sprintVelocity.DeveloperCount = distinctEmployees.Single(x => x.SprintNumber.Equals(sprintVelocity.SprintNumber)).DeveloperCount;
                sprintVelocityDetails.Add(sprintVelocity);
            }

            return sprintVelocityDetails;
        }

         public List<dynamic> GetEmployeeCountPerSprint(QueryFactory db, List<string> sprintUIDs)
        {
            

            var query = db.Query(sprints)
                .Join(workItems, sprints + ".SprintUID", workItems + ".SprintUID")
                .Select(sprints + ".SprintNumber", "DevOps.WorkItems.ResolvedBy as EmpId").Distinct();

            if (sprintUIDs.Count > 0)
                query = query.WhereIn(sprints + ".SprintUID", sprintUIDs);

            query = query.As("A");

            var distinctEmployees = db.Query().From(query)
                .Select("A.SprintNumber").SelectRaw("COUNT(A.EmpId) as DeveloperCount")
            .GroupBy("A.SprintNumber");

            return distinctEmployees.Get<dynamic>().ToList();
        }

        
        public IEnumerable<dynamic> GetSprintWorkItemsCountByStatus(List<string> sprintUIDs)
        {
            
            var userStoriesStatus = GetQueryWorkItemsByStatus(db, sprintUIDs, "User Story").Get<dynamic>();
            var bugsStatus = GetQueryWorkItemsByStatus(db, sprintUIDs, "Bug").Get<dynamic>();

            List<dynamic> result = new List<dynamic>
            {
                userStoriesStatus,
                bugsStatus
            };

            return result;
        }

        private Query GetQueryWorkItemsByStatus(QueryFactory db, List<string> sprintUIDs, string workItemType)
        {
            var distinctSprints = db.Query(sprints)
                .Select("SprintNumber").SelectRaw("MAX(CreatedDate) as CreatedDate")
                .GroupBy("SprintNumber");

            var plannedItems = db.Query(sprints)
                .LeftJoin(workItems, x => x.On(sprints + ".SprintUID", workItems + ".SprintUID"))
                .Select(sprints + ".SprintUID").SelectRaw("COUNT(" + workItems + ".WorkItemId) as PlannedWorkItems")
                .Where(workItems + ".ItemType", workItemType)
                .GroupBy(sprints + ".SprintUID");

            var completedItems = db.Query(sprints)
                .LeftJoin(workItems, x => x.On(sprints + ".SprintUID", workItems + ".SprintUID")
                                    .Where(workItems + ".Status", "Closed"))
                .Select(sprints + ".SprintUID").SelectRaw("COUNT(" + workItems + ".WorkItemId) as CompletedWorkItems")
                .Where(workItems + ".ItemType", workItemType)
                .GroupBy(sprints + ".SprintUID");

            var IncompleteItems = db.Query(sprints)
                .LeftJoin(workItems, x => x.On(sprints + ".SprintUID", workItems + ".SprintUID")
                                    .WhereNot(workItems + ".Status", "Closed"))
                .Select(sprints + ".SprintUID").SelectRaw("COUNT(" + workItems + ".WorkItemId) as IncompleteWorkItems")
                .Where(workItems + ".ItemType", workItemType)
                .GroupBy(sprints + ".SprintUID");

            var query = db.Query(sprints)
                .Join(distinctSprints.As("B"), x => x.On(sprints + ".SprintNumber", "B.SprintNumber")
                                                    .On(sprints + ".CreatedDate", "B.CreatedDate"))
                .LeftJoin(plannedItems.As("C"), x => x.On(sprints + ".SprintUID", "C.SprintUID"))
                .LeftJoin(completedItems.As("D"), x => x.On(sprints + ".SprintUID", "D.SprintUID"))
                .LeftJoin(IncompleteItems.As("E"), x => x.On(sprints + ".SprintUID", "E.SprintUID"))
                .Select(sprints + ".SprintUID", sprints + ".SprintNumber", sprints + ".SprintName", sprints + ".EndDate as SprintEndDate")
                .SelectRaw("ISNULL(C.PlannedWorkItems, 0) PlannedWorkItems, ISNULL(D.CompletedWorkItems, 0) CompletedWorkItems, ISNULL(E.IncompleteWorkItems, 0) IncompleteWorkItems");

            if (sprintUIDs.Count > 0)
                query = query.WhereIn(sprints + ".SprintUID", sprintUIDs);

            query = query.OrderBy(sprints + ".SprintNumber");
            return query;
        }
    }
}
