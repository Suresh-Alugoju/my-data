﻿using SqlKata.Execution;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Dto;
using TM.Domain.Models.Common;

namespace TM.Domain.Repositories.TaskDetailsRepository
{
    public class TaskDetailsRepository : ITaskDetailsRepository
    {
        private readonly QueryFactory db;

        public TaskDetailsRepository(QueryFactory db)
        {
            this.db = db;
        }
        public IEnumerable<dynamic> Get()
        {
            var selectColumns = new[] {
            "DevOps.Sprints.SprintUID", "DevOps.Sprints.CreatedDate",
            "DevOps.WorkItems.WorkItemId", "DevOps.WorkItems.ItemType", "DevOps.WorkItems.Title", "DevOps.WorkItems.Points",
            "DevOps.WorkItems.Status as WorkItemStatus",
            "DevOps.WorkItemTask.TaskId", "DevOps.WorkItemTask.TaskName", "DevOps.Employees.EmpName",
            "DevOps.WorkItemTask.StartDate as TaskDate", "DevOps.WorkItemTask.Status as TaskStatus", "DevOps.WorkItemTask.DurationInHrs"};

            var lastSprint = db.Query(SqlKataCommon.Table_DevOpsSprints)
                            .Select("SprintUID").OrderByDesc("CreatedDate", "SprintNumber").Take(1);

            var query = db.Query(SqlKataCommon.Table_DevOpsSprints)
                          .Join(lastSprint.As("B"), x => x.On("B.SprintUID", "DevOps.Sprints.SprintUID"))
                          .Join(SqlKataCommon.Table_DevOpsWorkItems, "DevOps.Sprints.SprintUID", "DevOps.WorkItems.SprintUID")
                          .Join(SqlKataCommon.Table_DevOpsWorkItemTask, "DevOps.WorkItems.WorkItemId", "DevOps.WorkItemTask.WorkItemId")
                          .Join(SqlKataCommon.Table_DevOpsEmployees, "DevOps.WorkItemTask.EmpId", "DevOps.Employees.EmpId")
                          .Select(selectColumns)
                          .OrderBy("DevOps.WorkItemTask.StartDate");

            var result = query.Get<dynamic>();
            return result;
        }
    }
}
