﻿using SqlKata.Execution;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeamsModule_API.DTOs;
using TM.Domain.Dto;

namespace TM.Domain.Repositories.TeamMemberRemarksRepository
{
    public class TeamMemberRemarksRepository : ITeamMemberRemarksRepository
    {
        private readonly QueryFactory db;

        public TeamMemberRemarksRepository(QueryFactory db)
        {
            this.db = db;
        }

        public List<TdTeamMemberRemarksDTO> GetTeamMemberRemarks(int id)
        {
            try
            {
                IEnumerable<TdTeamMemberRemarksDTO> teamMemberRemarks;
                teamMemberRemarks = db.Query("Td_TeamMemberRemarks").Where("TeamMemberId", id).Get<TdTeamMemberRemarksDTO>();
                List<TdTeamMemberRemarksDTO> teamMemberRemarksList = teamMemberRemarks.ToList();
                teamMemberRemarksList.Reverse();
                return teamMemberRemarksList;
            }
            catch (Exception ex)
            {
                return null;
            }
            
        }

        public int PostTeamMemberRemarks(TdTeamMemberRemarksDTO remarkObj)
        {
            int id = 0;
            try
            {
                int affected = db.Query("Td_TeamMembers").Where("Id", remarkObj.TeamMemberId).Update(new
                {
                    Status = remarkObj.Status,
                });
                id = db.Query("Td_TeamMemberRemarks").InsertGetId<int>(new
                {
                    TeamMemberId = remarkObj.TeamMemberId,
                    Remark = remarkObj.Remark,
                    Status = remarkObj.Status
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return id;
        }

        public int DeleteTeamMemberRemarks(int id)
        {
            int affected = 0;
            try
            {
                affected = db.Query("Td_TeamMemberRemarks").Where("TeamMemberId", id).Delete();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return affected;
        }

        public int DeleteById(int id)
        {
            int affected = 0;
            try
            {
                affected = db.Query("Td_TeamMemberRemarks").Where("Id", id).Delete();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return affected;
        }

    }
}
