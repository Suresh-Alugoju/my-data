﻿using SqlKata.Execution;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Dto;
using TM.Domain.Models;
using TM.Domain.Models.Common;

namespace TM.Domain.Repositories.CommonRepository
{
    public class CommonRepository : ICommonRepository
    {
        private readonly QueryFactory db;
        public CommonRepository(QueryFactory db)
        {
            this.db = db;
        }
        public IEnumerable<Sprint> GetSprints()
        {
            //SQL Query
            //select A.SprintUID, A.SprintNumber, SprintName, A.CreatedDate, StartDate, EndDate
            //from DevOps.Sprints A
            //join(
            //        select SprintNumber, MAX(CreatedDate) CreatedDate
            //        from DevOps.Sprints B
            //        group by SprintNumber
            //    ) B on A.SprintNumber = B.SprintNumber and A.CreatedDate = B.CreatedDate

            string sprints = SqlKataCommon.Table_DevOpsSprints;
           // var db = _connectionCommon.GetQueryFactory();

            var distinctSprints = db.Query(sprints)
                .Select("SprintNumber").SelectRaw("MAX(CreatedDate) as CreatedDate")
                .GroupBy("SprintNumber");

            return db.Query(sprints)
                .Join(distinctSprints.As("B"), x => x.On(sprints + ".SprintNumber", "B.SprintNumber")
                                                    .On(sprints + ".CreatedDate", "B.CreatedDate"))
                .Select(sprints + ".SprintUID", sprints + ".SprintNumber", sprints + ".SprintName", sprints + ".CreatedDate", sprints + ".StartDate", sprints + ".EndDate")
                .OrderByDesc(sprints + ".CreatedDate", sprints + ".SprintNumber").Get<Sprint>().Distinct();
        }
    }
}
