﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeamsModule_API.Models;
//using TM.Domain.Dto;

namespace TM.Domain.Repositories.DashboardRepository
{
    public interface IDashboardRepository
    {
        List<TdDashboardDTO> GetTdDashboard();
    }
}

