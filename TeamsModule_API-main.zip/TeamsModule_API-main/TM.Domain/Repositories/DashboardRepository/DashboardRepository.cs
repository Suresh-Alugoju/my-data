﻿using SqlKata.Execution;
using TeamsModule_API.DTOs;
using TeamsModule_API.Models;
using TM.Domain.Models;
using TM.Domain.Repositories.DashboardRepository;

namespace TM.Domain.Repositories.DashboardRepository
{
    public class DashboardRepository : IDashboardRepository
    {
        private readonly QueryFactory db;

        public DashboardRepository(QueryFactory db)
        {
            this.db = db;
        }
        public List<TdDashboardDTO> GetTdDashboard()
        {

            List<TdDashboardDTO> dashboard1 = new List<TdDashboardDTO>();
     

            try
            {
                List<TdTeamDetailDTO> dashboard = db.Query("Td_TeamDetails").Get<TdTeamDetailDTO>().ToList();
                dashboard1.Add(new TdDashboardDTO { name="All Teams", count=dashboard.Count() });
                // dashboard1.TdTeamDetailCount = dashboard.Count();


                List<TdTeamMemberDTO> dashboard2 = db.Query("Td_TeamMembers").Get<TdTeamMemberDTO>().ToList();
                dashboard1.Add(new TdDashboardDTO { name = "All Members", count = dashboard2.Count() });
                //dashboard1.TdTeamMemberCount = dashboard2.Count();

                List<TdTeamMemberDTO> dashboard3 = db.Query("Td_TeamMembers").Where("Status", 2).Get<TdTeamMemberDTO>().ToList();
                dashboard1.Add(new TdDashboardDTO { name = "Status New", count = dashboard3.Count() });

                List<TdTeamMemberDTO> dashboard4 = db.Query("Td_TeamMembers").Where("Status", 3).Get<TdTeamMemberDTO>().ToList();
                dashboard1.Add(new TdDashboardDTO { name = "Status OnBoard", count = dashboard4.Count() });

                List<TdTeamMemberDTO> dashboard5 = db.Query("Td_TeamMembers").Where("Status", 4).Get<TdTeamMemberDTO>().ToList();
                dashboard1.Add(new TdDashboardDTO { name = "Status OffBoard", count = dashboard5.Count() });
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
            return dashboard1;
        }
    }
}
