﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using SqlKata.Execution;
using SqlKata;
using TM.Domain.Models.Common;

namespace TM.Domain.Repositories.TeamPerformanceRepository
{
    public class TeamPerformanceRepository:ITeamPerformanceRepository
    {

        private readonly QueryFactory db;
        public TeamPerformanceRepository(QueryFactory db)
        {
            this.db = db;
        }

        
        public List<dynamic> GetUserStoryPointsByStatusNEmployees(string sprintUID)
        {
            try
            {
                

                var NewWorkItems = GetUserStoryPointsByStatus(db, sprintUID, "New");
                var ActiveWorkItems = GetUserStoryPointsByStatus(db, sprintUID, "Active");
                var PRReviewWorkItems = GetUserStoryPointsByStatus(db, sprintUID, "PR Review");
                var DeliveredToQAWorkItems = GetUserStoryPointsByStatus(db, sprintUID, "Delivered To QA");
                var ResolvedWorkItems = GetUserStoryPointsByStatus(db, sprintUID, "Resolved");
                var ClosedWorkItems = GetUserStoryPointsByStatus(db, sprintUID, "Closed");
                var RemovedWorkItems = GetUserStoryPointsByStatus(db, sprintUID, "Removed");
                var OtherWorkItems = GetUserStoryPointsByStatus(db, sprintUID, "Other");

                var teamPerformance = db.Query("DevOps.Employees")
                 .LeftJoin(NewWorkItems.As("B"), x => x.On("DevOps.Employees.EmpId", "B.ResolvedBy"))
                 .LeftJoin(ActiveWorkItems.As("C"), x => x.On("DevOps.Employees.EmpId", "C.ResolvedBy"))
                 .LeftJoin(PRReviewWorkItems.As("D"), x => x.On("DevOps.Employees.EmpId", "D.ResolvedBy"))
                 .LeftJoin(DeliveredToQAWorkItems.As("E"), x => x.On("DevOps.Employees.EmpId", "E.ResolvedBy"))
                 .LeftJoin(ResolvedWorkItems.As("F"), x => x.On("DevOps.Employees.EmpId", "F.ResolvedBy"))
                 .LeftJoin(ClosedWorkItems.As("G"), x => x.On("DevOps.Employees.EmpId", "G.ResolvedBy"))
                 .LeftJoin(RemovedWorkItems.As("H"), x => x.On("DevOps.Employees.EmpId", "H.ResolvedBy"))
                 .LeftJoin(OtherWorkItems.As("I"), x => x.On("DevOps.Employees.EmpId", "I.ResolvedBy"))
                .Select("DevOps.Employees.EmpName", "DevOps.Employees.EmpEmail")
                .SelectRaw("ISNULL(B.New, 0) New, ISNULL(C.Active, 0) Active, ISNULL(D.PRReview, 0) PRReview, ISNULL(E.DeliveredToQA, 0) DeliveredToQA, ISNULL(F.Resolved, 0) Resolved, ISNULL(G.Closed, 0) Closed, ISNULL(H.Removed, 0) Removed, ISNULL(I.Other, 0) Other")
                .Where("New", ">", 0).OrWhere("Active", ">", 0).OrWhere("PRReview", ">", 0)
                .OrWhere("DeliveredToQA", ">", 0).OrWhere("Resolved", ">", 0).OrWhere("Closed", ">", 0)
                .OrWhere("Removed", ">", 0).OrWhere("Other", ">", 0)
                .Get();

                return teamPerformance.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Query GetUserStoryPointsByStatus(QueryFactory db, string sprintUID, string status)
        {
            string columnAlias = status.Replace(" ", "");
            var query = db.Query("DevOps.WorkItems")
               .Select("DevOps.WorkItems.ResolvedBy").SelectRaw($"ISNULL(SUM(Points), 0) as {columnAlias}")
               .Where("DevOps.WorkItems.ItemType", "User Story")
               .Where("DevOps.WorkItems.SprintUID", sprintUID);

            if (status == "Other")
                query = query.WhereNotIn("DevOps.WorkItems.Status", new string[] { "New", "Active", "PR Review", "Delivered to QA", "Closed", "Resolved", "Removed" });
            else
                query = query.Where("DevOps.WorkItems.Status", status);

            query = query.GroupBy("DevOps.WorkItems.ResolvedBy");

            return query;
        }

        
        public List<dynamic> GetUserStoryPointsByEmployees(string sprintUID)
        {
            try
            {
                var EmployeePointsDetails = db.Query(SqlKataCommon.Table_DevOpsEmployees)
                      .Join(SqlKataCommon.Table_DevOpsWorkItems, j => j.On("DevOps.WorkItems.ResolvedBy", "DevOps.Employees.EmpId"))
                      .Join(SqlKataCommon.Table_DevOpsSprints, j => j.On("DevOps.Sprints.SprintUID", "DevOps.WorkItems.SprintUID"))
                      .Where("DevOps.Sprints.SprintUID", sprintUID)
                      .Where("DevOps.WorkItems.ItemType", "User Story")
                      .Select("EmpName")
                      .SelectRaw("SUM(WorkItems.Points) as Points")
                      .GroupBy("DevOps.Employees.EmpName").Get();

                return EmployeePointsDetails.ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        
        public List<dynamic> GetBugsCountBySeverityNEmployees(string sprintUID)
        {
            try
            {
                var EmployeeBugCount = db.Query(SqlKataCommon.Table_DevOpsEmployees)
                      .Join(SqlKataCommon.Table_DevOpsWorkItems, j => j.On("DevOps.WorkItems.ResolvedBy", "DevOps.Employees.EmpId"))
                      .Where("DevOps.WorkItems.SprintUID", sprintUID)
                      .Where("DevOps.WorkItems.ItemType", "Bug")
                      .Select("EmpName", "EmpEmail", "DevOps.WorkItems.Severity").Get();
                var workItemsCountSeverity = (from num in EmployeeBugCount
                                              group num by new { num.EmpName, num.EmpEmail } into ItemSeverity
                                              orderby ItemSeverity.Key.EmpName
                                              select new
                                              {
                                                  ItemSeverity.Key.EmpName,
                                                  ItemSeverity.Key.EmpEmail,
                                                  Critical = ItemSeverity.Count(x => x.Severity == "1 - Critical"),
                                                  High = ItemSeverity.Count(x => x.Severity == "2 - High"),
                                                  Medium = ItemSeverity.Count(x => x.Severity == "3 - Medium"),
                                                  Low = ItemSeverity.Count(x => x.Severity == "4 - Low"),
                                                  Total = ItemSeverity.Count(x => x.EmpEmail == ItemSeverity.Key.EmpEmail)
                                              });

                return new List<dynamic> { workItemsCountSeverity };
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }


        public List<dynamic> GetBugsCountByEmployees(string sprintUID)
        {
            try
            {
                var EmployeeBugsDetails = db.Query(SqlKataCommon.Table_DevOpsEmployees)
                      .Join(SqlKataCommon.Table_DevOpsWorkItems, j => j.On("DevOps.WorkItems.ResolvedBy", "DevOps.Employees.EmpId"))
                      .Where("DevOps.WorkItems.SprintUID", sprintUID)
                      .Where("DevOps.WorkItems.ItemType", "Bug")
                      .Select("EmpName")
                      .SelectRaw("Count(WorkItems.WorkItemId) as BugCount")
                      .GroupBy("DevOps.Employees.EmpName").Get();

                return EmployeeBugsDetails.ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }
}