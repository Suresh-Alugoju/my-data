﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SqlKata.Execution;
using SqlKata;

namespace TM.Domain.Repositories.TeamPerformanceRepository
{
    public interface ITeamPerformanceRepository
    {
         List<dynamic> GetUserStoryPointsByStatusNEmployees(string sprintUID);
        Query GetUserStoryPointsByStatus(QueryFactory db, string sprintUID, string status);
        List<dynamic> GetUserStoryPointsByEmployees(string sprintUID);
        List<dynamic> GetBugsCountBySeverityNEmployees(string sprintUID);
        List<dynamic> GetBugsCountByEmployees(string sprintUID);

    }
}
