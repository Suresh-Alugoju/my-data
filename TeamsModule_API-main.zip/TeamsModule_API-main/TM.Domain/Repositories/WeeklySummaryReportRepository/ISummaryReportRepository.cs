﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Dto;

namespace TM.Domain.Repositories.WeeklySummaryReportRepository
{
    public interface ISummaryReportRepository
    {
        public WeeklySummaryReport GetSummaryReport(DateTime? WeekEndingDate);
        public bool AddWeeklySummaryReport(WeeklySummaryReport weeklySummaryReport);
        public List<WeeklySummaryReport> GetDataSummaryReport(DateTime StartDate, DateTime WeekEndingDate);
        public bool UpdateWeeklySummaryReport(int SummaryID, WeeklySummaryReport weeklySummaryReport);
    }
}
