﻿using SqlKata.Execution;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Dto;

namespace TM.Domain.Repositories.TeamMemberSkillsRepository
{
    public class TeamMemberSkillsRepository : ITeamMemberSkillsRepository
    {
        private readonly QueryFactory db;

        public TeamMemberSkillsRepository(QueryFactory db)
        {
            this.db = db;
        }

        public List<TdTeamMemberSkillsDTO> GetTeamMemberSkills(int id)
        {
            try
            {
                IEnumerable<TdTeamMemberSkillsDTO> teamMemberSkills;
                teamMemberSkills = db.Query("Td_TeamMemberSkills").Where("TeamMemberId", id).Get<TdTeamMemberSkillsDTO>();
                List<TdTeamMemberSkillsDTO> teamMemberRemarksList = teamMemberSkills.ToList();
                return teamMemberRemarksList;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public int PostTeamMemberSkills(TdTeamMemberSkillsDTO skillsdto)
        {
            int id = 0;
            try
            {
               
                id = db.Query("Td_TeamMemberSkills").InsertGetId<int>(new
                {
                    TeamMemberId = skillsdto.TeamMemberId,
                    SkillName = skillsdto.SkillName,
                    SkillType = skillsdto.SkillType
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return id;

        }
        public int DeleteTeamMemberSkills(int id)
        {
            int affected = 0;
            try
            {
                affected = db.Query("Td_TeamMemberSkills").Where("TeamMemberId", id).Delete();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return affected;

        }
        public int DeleteById(int id)
        {
            int affected = 0;
            try
            {
                affected = db.Query("Td_TeamMemberSkills").Where("Id", id).Delete();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return affected;
        }
    }
}
