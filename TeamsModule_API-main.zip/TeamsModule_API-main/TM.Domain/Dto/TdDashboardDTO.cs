﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Models;

namespace TeamsModule_API.Models
{
    public partial class TdDashboardDTO
    {
        public string? name { get; set; } = string.Empty;
        public int? count { get; set; }
    }
}





