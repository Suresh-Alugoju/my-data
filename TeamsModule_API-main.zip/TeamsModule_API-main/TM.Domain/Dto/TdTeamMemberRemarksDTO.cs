﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TM.Domain.Dto
{
    public partial class TdTeamMemberRemarksDTO
    {
        public int Id { get; set; }
        public int TeamMemberId { get; set; }
        public string Remark { get; set; } = string.Empty;
        public DateTime RemarkDate { get; set; }
        public byte IsActive { get; set; }

        public int? Status { get; set; }
    }
}
