﻿namespace TM.Domain.Dto
{
    public class Response
    {
        public string Data { get; set; }
        public int StatusCode { get; set; }
        public string Message { get; set; }
    }
}
