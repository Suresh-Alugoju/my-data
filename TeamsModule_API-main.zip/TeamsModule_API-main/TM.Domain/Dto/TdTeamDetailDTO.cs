﻿using System;
using System.Collections.Generic;
using TM.Domain.Models;

namespace TeamsModule_API.Models
{
    public partial class TdTeamDetailDTO
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string? Cli_Lead { get; set; }
        public string? Per_Lead { get; set; }
        public string? ScrumMaster { get; set; }
        public string? ProjectName { get; set; }
        public int TotalSize { get; set; }
        public int? Status { get; set; }
        public int? TdTeamMemberCount { get; set; }

    }
}
