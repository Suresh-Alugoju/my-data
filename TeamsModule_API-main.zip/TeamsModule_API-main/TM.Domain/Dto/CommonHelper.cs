﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Models;

namespace TM.Domain.Dto
{
    public static class CommonHelper
    {
        public static IEnumerable<Dictionary<string, object>> GetKeyValuePair(this List<SprintData> sprintData)
        {
            var result = new List<Dictionary<string, object>>();
            for (int i = 0; i < sprintData.Count; i++)
            {
                var sprintDataRow = sprintData[i];
                if (sprintDataRow == null)
                    continue;

                result.Add(sprintDataRow.GetType().GetProperties().
                    ToDictionary(p => p.Name, p => p.GetValue(sprintDataRow)));
            }

            return result;
        }
    }
}
