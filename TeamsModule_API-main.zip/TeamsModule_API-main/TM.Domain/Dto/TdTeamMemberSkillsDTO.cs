﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TM.Domain.Dto
{
    public class TdTeamMemberSkillsDTO
    {
        public int Id { get; set; }
        public int TeamMemberId { get; set; }
        public string SkillName { get; set; } = string.Empty;
        public int? SkillType { get; set; }

    }
}
