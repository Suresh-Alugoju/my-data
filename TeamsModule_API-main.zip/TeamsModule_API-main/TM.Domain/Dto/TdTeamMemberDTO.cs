﻿using TeamsModule_API.Models;

using TM.Domain.Models;

 

namespace TeamsModule_API.DTOs

{

    public class TdTeamMemberDTO

    {

        public int Id { get; set; }

        public string? Name { get; set; }

        public string? TeamName { get; set; }

        public string? Cli_Lead { get; set; }

        public string? Email { get; set; }

        public string? PhoneNo { get; set; }

        public int? TeamModuleId { get; set; }

        public int? EmpId { get; set; }

        public int? Status { get; set; }

        public DateTime? JoiningDate { get; set; }

        public DateTime? BillingDate { get; set; }

        public DateTime? RelievingDate { get; set; }

        public string? TechStack { get; set; }

        public string? ReportingTo { get; set; }


    }
    public class TempDTO
    {
        public string TechStack { get; set; }
        public int? Count { get; set; }
    }


}


