﻿namespace TeamsModule_API.Properties
{
    public class student
    {
        public long sid { get; set; }
        public string? sname  { get; set; }
        public bool roll_number { get; set; }

    }
}
