using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using NLog;
using SqlKata.Compilers;
using SqlKata.Execution;
using System.Configuration;
using NLog;
using TeamsModule_API.Controllers;
using TeamsModule_API.CustomExceptionMiddleware;
using TeamsModule_API.Extensions;
using TeamsModule_API.Models;
using TM.Application.Services.MailService;
using TM.Application.Services.TeamMemberRemarksService;
using TM.Application.Services.TeamMemberService;
using TM.Domain.Models;
using TM.Application.Services.TeamPerformanceService;
using TM.Application.Services.VelocityService;
using TM.Application.Services.WorkAnalysisService;
using TM.Application.Services.WorkItemByStateService;
using TM.Application.Services.TeamMemberSkillsService;
using TM.Application.Services.WeeklySummaryReportService;
using TM.Domain.Repositories.LoggerService;
using TM.Application.Services.WorkStatusService;
using TM.Domain.Repositories.WorkStatusRepository;
using TM.Domain.Repositories.TeamDetailsRepository;
using TM.Domain.Repositories.TeamMemberRemarksRepository;
using TM.Domain.Repositories.TeamMemberRepository;
using TM.Application.Services.CommonService;
using TM.Domain.Repositories.CommonRepository;
using TM.Application.Services.SprintDataService;
using TM.Domain.Repositories.SprintDataRepository;
using TM.Application.Services.TaskDetailsService;
using TM.Domain.Repositories.TaskDetailsRepository;
using TM.Application.Services.PerformanceService;
using TM.Domain.Repositories.PerformanceRepository;
using TM.Domain.Repositories.TeamPerformanceRepository;
using TM.Domain.Repositories.VelocityRepository;
using TM.Domain.Repositories.WorkAnalysisRepository;
using TM.Domain.Repositories.WorkItemByStateRepository;
using TM.Domain.Repositories.TeamMemberSkillsRepository;
using TM.Domain.Repositories.WeeklySummaryReportRepository;
using TM.Application.Services.TimedHostedService;


using TM.Domain.Repositories.DashboardRepository;
using TM.Application.Services.TeamMemberRemarksService;
using TM.Application.Services.TeamMemberSkillsService;
using TM.Domain.Repositories.LoggerService;
using TM.Domain.Repositories.TeamMemberRemarksRepository;
using TM.Domain.Repositories.TeamMemberSkillsRepository;
using TM.Application.Services.TimedHostedService;
using Microsoft.Extensions.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

var connectionString = builder.Configuration.GetConnectionString("DefaultDbConnection");

builder.Services.Configure<MailSettings>(builder.Configuration.GetSection("MailSettings"));



builder.Services.AddTransient<QueryFactory>((e) =>
{
    var connection = new SqlConnection(connectionString);
    SqlServerCompiler compiler = new SqlServerCompiler();
    return new QueryFactory(connection,
                            compiler);
});
builder.Services.AddSingleton<IConfiguration>(builder.Configuration);
builder.Services.AddScoped<ITeamPerformanceService, TeamPerformanceService>();
builder.Services.AddScoped<ITeamPerformanceRepository, TeamPerformanceRepository>();
builder.Services.AddScoped<IVelocityService, VelocityService>();
builder.Services.AddScoped<IVelocityRepository, VelocityRepository>();
builder.Services.AddScoped<IWorkAnalysisService, WorkAnalysisService>();
builder.Services.AddScoped<IWorkAnalysisRepository, WorkAnalysisRepository>();
builder.Services.AddScoped<IWorkItemByStateService, WorkItemByStateService>();
builder.Services.AddScoped<IWorkItemByStateRepository, WorkItemByStateRepository>();
builder.Services.AddScoped<ITeamDetailService, TeamDetailService>();
builder.Services.AddScoped<ITeamDetailsRepository, TeamDetailsRepository>();
builder.Services.AddScoped<ITeamMemberService, TeamMemberService>();
builder.Services.AddScoped<ITeamMemberRepository, TeamMemberRepository>();
builder.Services.AddTransient<IMailService, MailService>();
builder.Services.AddScoped<IDashboardRepository, DashboardRepository>();
builder.Services.AddScoped<ITeamMemberRemarksService, TeamMemberRemarksService>();
builder.Services.AddScoped<ITeamMemberRemarksRepository, TeamMemberRemarksRepository>();
builder.Services.AddScoped<ITeamMemberSkillsService, TeamMemberSkillsService>();
builder.Services.AddScoped<ITeamMemberSkillsRepository, TeamMemberSkillsRepository>();
builder.Services.AddTransient<ILoggerManager, LoggerManager>();


builder.Services.AddScoped<IDashboardService, DashboardService>();


builder.Services.AddScoped<ITeamMemberRemarksService, TeamMemberRemarksService>();
builder.Services.AddScoped<ITeamMemberRemarksRepository, TeamMemberRemarksRepository>();
builder.Services.AddScoped<ITeamMemberSkillsService, TeamMemberSkillsService>();
builder.Services.AddScoped<ITeamMemberSkillsRepository, TeamMemberSkillsRepository>();
builder.Services.AddScoped<ISummaryReportService, SummaryReportService>();
builder.Services.AddScoped<ISummaryReportRepository, SummaryReportRepository>();
builder.Services.AddTransient<ILoggerManager, LoggerManager>();
builder.Services.AddScoped<IWorkStatusService, WorkStatusService>();
builder.Services.AddScoped<IWorkStatusRepository, WorkStatusRepository>();
builder.Services.AddScoped<ICommonService, CommonService>();
builder.Services.AddScoped<ICommonRepository, CommonRepository>();
builder.Services.AddScoped<ISprintDataService, SprintDataService>();
builder.Services.AddScoped<ISprintDataRepository, SprintDataRepository>();
builder.Services.AddScoped<ITaskDetailsService, TaskDetailsService>();
builder.Services.AddScoped<ITaskDetailsRepository, TaskDetailsRepository>();
builder.Services.AddScoped<IPerformanceService, PerformanceService>();
builder.Services.AddScoped<IPerformanceRepository, PerformanceRepository>();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHostedService<TimedHostedService>();

var app = builder.Build();
//ILoggerManager logger = app.Services.GetRequiredService<ILoggerManager>();

app.UseMiddleware<ExceptionMiddleware>();


app.UseCors(options =>
{
    options.AllowAnyOrigin();
    options.AllowAnyMethod();
    options.AllowAnyHeader();
});

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

//app.ConfigureExceptionHandler(logger);
app.ConfigureCustomExceptionMiddleware();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
