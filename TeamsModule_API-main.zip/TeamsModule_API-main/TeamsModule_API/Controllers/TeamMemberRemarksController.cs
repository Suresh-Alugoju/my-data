﻿using Microsoft.AspNetCore.Mvc;
using TM.Application.Services.TeamMemberRemarksService;
using TM.Domain.Dto;

namespace TeamsModule_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamMemberRemarksController : ControllerBase
    {
        private readonly ITeamMemberRemarksService _teamMemberRemarks;

        public TeamMemberRemarksController(ITeamMemberRemarksService teamMemberRemarks)
        {
            _teamMemberRemarks = teamMemberRemarks;
        }

        [HttpGet("{id}")]
        public List<TdTeamMemberRemarksDTO> GetTeamMemberRemarks(int id)
        {
            return _teamMemberRemarks.GetTeamMemberRemarks(id);
        }

        [HttpPost]
        public int PostTeamMemberRemarks(TdTeamMemberRemarksDTO remarkObj)
        {
            return _teamMemberRemarks.PostTeamMemberRemarks(remarkObj);
        }

        [HttpDelete("{id}")]
        public int DeleteTeamMemberRemarks(int id)
        {
            return _teamMemberRemarks.DeleteTeamMemberRemarks(id);
        }

        [HttpDelete("byId/{id}")]
        public int DeleteById(int id)
        {
            return _teamMemberRemarks.DeleteById(id);
        }
    }
}
