﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SqlKata.Execution;
using TeamsModule_API.Models;
using TM.Domain.Repositories.LoggerService;

namespace TeamsModule_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamDetailController : ControllerBase
    {

        private readonly ITeamDetailService _teamDetails;
        private readonly ILoggerManager _logger;

        public TeamDetailController(ITeamDetailService teamDetails, ILoggerManager logger)
        {
            _teamDetails = teamDetails;
            _logger = logger;
        }

        // GET: api/TeamDetail
        [HttpGet]
        public IEnumerable<TdTeamDetailDTO> GetTdTeamDetails()
        {
            return _teamDetails.GetTdTeamDetails();
        }

        // GET: api/TeamDetail/5
        [HttpGet("{id}")]
        public IEnumerable<TdTeamDetailDTO> GetTdTeamDetail(int id)
        {
        
            //_logger.LogInfo("Returning Team Details with id: " + id);
            var teamDetails =  _teamDetails.GetTdTeamDetail(id);
            //throw new Exception("Exception while fetching all the students from the storage.");
            return teamDetails;
        }

        // PUT: api/TeamDetail/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public int PutTdTeamDetail(int id, TdTeamDetailDTO tdTeamDetaildto)
        {
            return _teamDetails.PutTdTeamDetail(id, tdTeamDetaildto);
        }

        // POST: api/TeamDetail
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public int PostTdTeamDetail(TdTeamDetailDTO tdTeamDetaildto)
        {
            return _teamDetails.PostTdTeamDetail(tdTeamDetaildto);
        }

        // DELETE: api/TeamDetail/5
        [HttpDelete("{id}")]
        public int DeleteTdTeamDetail(int id)
        {
            return _teamDetails.DeleteTdTeamDetail(id);

        }

    }
}
