﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TeamsModule_API.Models;
using TM.Domain.Repositories.TeamDetailsRepository;

namespace TeamsModule_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChartController : ControllerBase
    {
        private readonly ITeamDetailsRepository _teamDetails;

        public ChartController(ITeamDetailsRepository teamDetails)
        {
            _teamDetails = teamDetails;
        }

        [HttpGet]
        public IEnumerable<TdTeamDetailDTO> GetTdChart()
        {
            return _teamDetails.GetBarchartTd();
        }
    }
}
