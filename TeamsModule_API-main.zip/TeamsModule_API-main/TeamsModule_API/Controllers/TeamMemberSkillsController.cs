﻿using Microsoft.AspNetCore.Mvc;
using TM.Application.Services.TeamMemberRemarksService;
using TM.Application.Services.TeamMemberSkillsService;
using TM.Domain.Dto;

namespace TeamsModule_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamMemberSkillsController : ControllerBase
    {
        private readonly ITeamMemberSkillsService _teamMemberSkills;

        public TeamMemberSkillsController(ITeamMemberSkillsService teamMemberSkills)
        {
            _teamMemberSkills = teamMemberSkills;
        }

        [HttpGet("{id}")]
        public List<TdTeamMemberSkillsDTO> GetTeamMemberRemarks(int id)
        {
            return _teamMemberSkills.GetTeamMemberSkills(id);
        }

        [HttpPost]
        public int PostTeamMemberRemarks(TdTeamMemberSkillsDTO skills)
        {
            return _teamMemberSkills.PostTeamMemberSkills(skills);
        }

        [HttpDelete("{id}")]
        public int DeleteTeamMemberRemarks(int id)
        {
            return _teamMemberSkills.DeleteTeamMemberSkills(id);
        }

        [HttpDelete("byId/{id}")]
        public int DeleteById(int id)
        {
            return _teamMemberSkills.DeleteById(id);
        }
    }
}
