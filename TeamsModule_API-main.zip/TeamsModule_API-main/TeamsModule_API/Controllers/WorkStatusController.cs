﻿using Microsoft.AspNetCore.Mvc;
using TM.Application.Services.WorkStatusService;
using TM.Domain.Models;

namespace TeamsModule_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WorkStatusController : ControllerBase
    {
        
        private readonly IWorkStatusService _workStatusService;
        public WorkStatusController(IWorkStatusService workStatus)
        {
           
            _workStatusService= workStatus;
        }
      
        [HttpPost]
        [Route("GetStatusCountData")]
        public IEnumerable<dynamic> GetStatusCountData([FromBody] List<string> sprintUIDs)
        {
            return _workStatusService.GetStatusCountData(sprintUIDs);

        }

        [HttpPost]
        [Route("GetBugSeverityCount")]
        public IEnumerable<dynamic> GetBugSeverityCount([FromBody] List<string> sprintUIDs)
        {
            return _workStatusService.GetBugSeverityCount(sprintUIDs);

        }

        [HttpPost]
        [Route("GetUserStoryPointsCount")]
        public IEnumerable<dynamic> GetUserStoryPointsCount([FromBody] List<string> sprintUIDs)
        {
            return _workStatusService.GetUserStoryPointsCount(sprintUIDs);
        }
    }
}
