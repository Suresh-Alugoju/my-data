﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SqlKata.Execution;
using TeamsModule_API.Models;
using System.Collections.Generic;



namespace TeamsModule_API.Controllers


{
    [Route("api/[controller]")]
    [ApiController]
    public class DashboardController : ControllerBase
    {
        private readonly IDashboardService _dashboard;

        public DashboardController(IDashboardService dashboard)
        {
            _dashboard = dashboard;
        }

        // GET: api/Dashboard
        [HttpGet]
        public List<TdDashboardDTO> GetTdDashboard()
        {
            return _dashboard.GetTdDashboard();

        }
    }
}
