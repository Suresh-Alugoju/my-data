﻿using Microsoft.AspNetCore.Mvc;
using TM.Application.Services.TaskDetailsService;

namespace TeamsModule_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskDetailsController : Controller
    {
        private readonly ILogger<TaskDetailsController> _logger;
        private readonly ITaskDetailsService _taskDetailsService;

        public TaskDetailsController(ITaskDetailsService taskDetails, ILogger<TaskDetailsController> logger)
        {
            _logger = logger;
            _taskDetailsService = taskDetails;

        }
       
       [HttpGet]
        public IEnumerable<dynamic> Get()
        {
            return _taskDetailsService.Get();
        }
    }
}
