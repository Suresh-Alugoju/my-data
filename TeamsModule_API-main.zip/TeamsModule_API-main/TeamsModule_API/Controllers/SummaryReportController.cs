﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TM.Domain.Dto;

using TM.Application.Services.WeeklySummaryReportService;
using TM.Domain.Repositories.LoggerService;

namespace TeamsModule_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SummaryReportController : ControllerBase
    {
        ISummaryReportService _summaryReportService;
        private readonly ILoggerManager _logger;
        public SummaryReportController(ISummaryReportService summaryReportService, ILoggerManager logger)
        {
            _summaryReportService = summaryReportService;
            _logger = logger;
        }
        [HttpGet]
        [Route("/GetWeeklySummaryReport")]
        public Response GetWeeklySummaryReport(DateTime? WeekEndingDate)
        {
            return _summaryReportService.GetWeeklySummaryReport(WeekEndingDate);
        }

        // POST api/<ActionItemController>
        [HttpPost]
        [Route("/AddWeeklySummaryReport")]
        public Response Post([FromBody] WeeklySummaryReport weeklySummaryReport)
        {
            return _summaryReportService.AddWeeklySummaryReport(weeklySummaryReport);
        }

        // PUT api/<ActionItemController>/5
        [HttpPut]
        [Route("/UpdateWeeklySummaryReport")]
        public Response Put(int SummaryID, [FromBody] WeeklySummaryReport weeklySummaryReport)
        {
            return _summaryReportService.UpdateWeeklySummaryReport(SummaryID, weeklySummaryReport);
        }

        [HttpGet]
        [Route("/GetDateSummaryReport")]
        public Response GetDateSummaryReport(DateTime StartDate, DateTime WeekEndingDate)
        {
            return _summaryReportService.GetDateSummaryReport(StartDate, WeekEndingDate);
        }
    }
}