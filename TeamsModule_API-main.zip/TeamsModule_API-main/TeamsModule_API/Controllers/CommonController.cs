﻿using Microsoft.AspNetCore.Mvc;
using TM.Application.Services.CommonService;
using TM.Application.Services.WorkStatusService;
using TM.Domain.Models;

namespace TeamsModule_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommonController : Controller
    {
        
        private readonly ILogger<CommonController> _logger;

        private readonly ICommonService _commonService;
        public CommonController(ICommonService common, ILogger<CommonController> logger)
        {
            _logger = logger;
            _commonService = common;
           
        }
        [HttpGet]
        public IEnumerable<Sprint> GetSprints()
        {
            return _commonService.GetSprints();
        }
    }
}
