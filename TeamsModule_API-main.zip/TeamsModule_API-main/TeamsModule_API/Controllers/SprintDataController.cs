﻿using ExcelDataReader;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Text;
using TM.Application.Services.SprintDataService;
using TM.Domain.Dto;
using TM.Domain.Models;
using TM.Domain.Repositories.LoggerService;

namespace TeamsModule_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]   
    public class SprintDataController : Controller
    {
        private readonly ISprintDataService _sprintDataService;
        private readonly ILoggerManager _logger;

        public SprintDataController(ISprintDataService sprintData, ILoggerManager logger)
        {
            _sprintDataService = sprintData;
            _logger = logger;
        }
        
       [HttpGet]
        public IEnumerable<SprintData> Get()
        {
            return _sprintDataService.Get();
        }

        [HttpPost]
        public IActionResult UploadExcel()
        {
            try
            {
                string errorMessage = "";
                List<SprintData>? sprintData = UploadExcelAndExtractSprintData(out errorMessage);
                if (sprintData == null || !String.IsNullOrEmpty(errorMessage))
                    return BadRequest(errorMessage);

                var data = sprintData.GetKeyValuePair();
                //  var db = _connectionCommon.GetQueryFactory();

                int successRows = 0, failedRows = 0;
                StringBuilder sb = new StringBuilder();

                foreach (var sprintDataRow in sprintData)
                {
                    try
                    {
                        if (sprintDataRow == null)
                            continue;
                        _sprintDataService.Upsert(sprintDataRow);
                        // db.Query(SqlKataCommon.Table_DevOpsSprintData).Insert(sprintDataRow);
                        successRows++;
                    }
                    catch (Exception ex)
                    {
                        failedRows++;
                        Console.WriteLine(ex.Message);
                        sb.AppendLine(@$"Id: {sprintDataRow.Id}   Error: {ex.Message} <br/>");
                        continue;
                    }
                }

                if (String.IsNullOrEmpty(sb.ToString()) && successRows == sprintData.Count)
                    return StatusCode(StatusCodes.Status200OK);

                //still here, few records failed
                StringBuilder sb2 = new StringBuilder();
                sb2.AppendLine(@$"{successRows} rows are processed out of {sprintData.Count}. {failedRows} rows failed. <br/>");
                sb2.AppendLine(sb.ToString());

                return StatusCode(StatusCodes.Status500InternalServerError, sb2.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }



        private List<SprintData>? UploadExcelAndExtractSprintData(out string errorMessage)
        {
            errorMessage = "";
            IFormFile file = HttpContext.Request.Form.Files[0];
            if (file == null)
            {
                errorMessage = "File is not received";
                return null;
            }

            IExcelDataReader reader;
            string dirPath = Path.Combine("../", "ReceivedSprintDetails");
            if (!Directory.Exists(dirPath))
                Directory.CreateDirectory(dirPath);

            string dataFileName = Path.GetFileName(file.FileName);
            string extension = Path.GetExtension(dataFileName);

            string[] allowedExtensions = new string[] { ".xls", ".xlsx" };
            if (String.IsNullOrEmpty(dataFileName))
            {
                errorMessage = "Invalid file name";
                return null;
            }

            if (!allowedExtensions.Contains(extension))
            {
                errorMessage = "Invalid file extension";
                return null;
            }

            // Make a Copy of the Posted File from the Received HTTP Request
            string saveToPath = Path.Combine(dirPath, dataFileName);
            using (FileStream stream = new FileStream(saveToPath, FileMode.Create))
            {
                file.CopyTo(stream);
            }

            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            dataFileName = dataFileName.Replace(".xlsx", "").Replace(".xls", "");
            Guid sprintUID = InsertSprintDetailsUsingFileName(dataFileName, out errorMessage);
            if (!String.IsNullOrEmpty(errorMessage))
                return null;

            List<SprintData> sprintData = new List<SprintData>();
            int prevWorkItemId = 0;

            // read the excel file
            using (var stream = new FileStream(saveToPath, FileMode.Open))
            {
                if (extension == ".xls")
                    reader = ExcelReaderFactory.CreateBinaryReader(stream);
                else
                    reader = ExcelReaderFactory.CreateOpenXmlReader(stream);

                DataSet ds = new DataSet();
                ds = reader.AsDataSet();
                DataTable excelDataTable = ds.Tables[0];
                DataTable returnTable = new DataTable();
                returnTable = excelDataTable.Clone();

                for (int i = 1; i < excelDataTable.Rows.Count; i++)
                {
                    DataRow excelRow = excelDataTable.Rows[i];
                    SprintData sprintDataRow = new SprintData();
                    sprintDataRow.SprintUID = sprintUID;

                    int ID = 0;
                    if (!Int32.TryParse(excelRow[0].ToString(), out ID))
                        ID = 0;

                    sprintDataRow.Id = ID;

                    sprintDataRow.WorkItemType = excelRow[1].ToString();
                    if (!sprintDataRow.WorkItemType.ToLower().Equals("task"))
                        prevWorkItemId = ID;

                    int parentID = 0;
                    if (!Int32.TryParse(excelRow[11].ToString(), out parentID))
                        parentID = 0;

                    if (sprintDataRow.WorkItemType.ToLower().Equals("task"))
                    {
                        if (parentID == 0 && prevWorkItemId > 0)
                            sprintDataRow.ParentId = prevWorkItemId;
                        else
                            sprintDataRow.ParentId = parentID;
                    }

                    sprintDataRow.Title = excelRow[2].ToString();
                    sprintDataRow.AssignedTo = excelRow[3].ToString();
                    sprintDataRow.State = excelRow[4].ToString();
                    sprintDataRow.Tags = excelRow[5].ToString();
                    sprintDataRow.ResolvedBy = excelRow[6].ToString();

                    double completedWork = 0;
                    if (!Double.TryParse(excelRow[7].ToString(), out completedWork))
                        completedWork = 0;

                    sprintDataRow.CompletedWork = completedWork;

                    sprintDataRow.Severity = excelRow[8].ToString();

                    DateTime createdDate = DateTime.Today;
                    if (!DateTime.TryParse(excelRow[9].ToString(), out createdDate))
                        createdDate = DateTime.Today;

                    sprintDataRow.CreatedDate = createdDate;

                    double storyPoints = 0;
                    if (!Double.TryParse(excelRow[10].ToString(), out storyPoints))
                        storyPoints = 0;

                    sprintDataRow.StoryPoints = storyPoints;
                    sprintData.Add(sprintDataRow);
                }

                reader.Close();
            }

            //sort the records by ParentID and ID to avoid FK issues
            sprintData = sprintData.OrderBy(x => x.ParentId).ThenBy(x => x.Id).ToList();
            return sprintData;
        }

        private Guid InsertSprintDetailsUsingFileName(string fileName, out string errorMessage)
        {
            errorMessage = "";

            //SprintNumber_StartDate(dd MMM yyyy)_EndDate(dd MMM yyyy)
            string[] values = fileName.Split('_');
            if (values == null || values.Length == 0)
            {
                errorMessage = "Invalid file name";
                return Guid.Empty;
            }

            DateTime startDate = DateTime.MinValue, endDate = DateTime.MinValue;
            if (!DateTime.TryParse(values[1], out startDate) || !DateTime.TryParse(values[2], out endDate))
            {
                errorMessage = "Invalid file name";
                return Guid.Empty;
            }

            Sprint sprint = new Sprint()
            {
                SprintUID = Guid.NewGuid(),
                CreatedDate = DateTime.Now,
                SprintNumber = values[0],
                SprintName = values[0],
                StartDate = startDate,
                EndDate = endDate

            };
            _sprintDataService.UpsertSprint(sprint);
            // db.Query(SqlKataCommon.Table_DevOpsSprints).Insert(sprint);
            return sprint.SprintUID;
        }

    }
}
