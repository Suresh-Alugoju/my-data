﻿using Microsoft.AspNetCore.Mvc;
using SqlKata;
using SqlKata.Execution;
using TeamsModule_API.Controllers;
using TM.Application.Services.TeamPerformanceService;

namespace DevOps.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TeamPerformanceController : ControllerBase
    {
        private readonly ILogger<TeamPerformanceController> _logger;
        private readonly ITeamPerformanceService _teamPerformance;

        public TeamPerformanceController(ILogger<TeamPerformanceController> logger, ITeamPerformanceService teamPerf)
        {
            _logger = logger;
            _teamPerformance = teamPerf;
            
        }

        [HttpGet]
        [Route("GetUserStoryPointsByStatusNEmployees")]
        public List<dynamic> GetUserStoryPointsByStatusNEmployees(string sprintUID)
        {
            try
            {
                return _teamPerformance.GetUserStoryPointsByStatusNEmployees(sprintUID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("GetUserStoryPointsByEmployees")]
        public List<dynamic> GetUserStoryPointsByEmployees(string sprintUID)
        {
            try
            {
                return _teamPerformance.GetUserStoryPointsByEmployees(sprintUID);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        [HttpGet]
        [Route("GetBugsCountBySeverityNEmployees")]
        public List<dynamic> GetBugsCountBySeverityNEmployees(string sprintUID)
        {
            try
            {
                return _teamPerformance.GetBugsCountBySeverityNEmployees(sprintUID);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        [HttpGet]
        [Route("GetBugsCountByEmployees")]
        public List<dynamic> GetBugsCountByEmployees(string sprintUID)
        {
            try
            {
               
                return _teamPerformance.GetBugsCountByEmployees(sprintUID);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }
}
