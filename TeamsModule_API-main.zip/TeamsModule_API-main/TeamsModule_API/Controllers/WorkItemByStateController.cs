﻿using Microsoft.AspNetCore.Mvc;
using SqlKata.Execution;
using TM.Application.Services.TeamMemberRemarksService;
using TM.Application.Services.WorkItemByStateService;
using TM.Domain.Models;
using TM.Domain.Models.Common;
//using static DevOps.CommonAPI.CommonCode;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TeamsModule_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WorkItemByStateController : ControllerBase
    {
        private readonly IWorkItemByStateService _workItem;

        public WorkItemByStateController(IWorkItemByStateService workItem)
        {
            _workItem = workItem;
        }

        [HttpGet]
        public IEnumerable<WorkItemByState> Get()
        {
            try
            {
                return _workItem.Get();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        [HttpGet]
        [Route("GetWorkItems")]
        public IEnumerable<WorkItem>? GetWorkItems()
        {
            return _workItem.GetWorkItems();
        }

        [HttpGet]
        [Route("GetWorkItemsBySprint")]
        public List<Object>? GetWorkItemsBySprint(Guid sprintUID, string workItemType)
        {
            return _workItem.GetWorkItemsBySprint(sprintUID,workItemType);
        }

        [HttpGet]
        [Route("GetEmployeeWorkItemCountByStatus")]
        public List<object>? GetEmployeeWorkItemCountByStatus(Guid SprintUID, string workItemType)
        {
            return _workItem.GetEmployeeWorkItemCountByStatus( SprintUID,  workItemType);
        }

        [HttpGet]
        [Route("GetEmployeeTaskCountByStatus")]
        public List<object>? GetEmployeeTaskCountByStatus(Guid SprintUID, string workItemType, string workItemId)
        {
            return _workItem.GetEmployeeTaskCountByStatus(SprintUID, workItemType, workItemId);
        }

        [HttpGet]
        [Route("GetWorkItemTasksData")]
        public List<Object> GetWorkItemTasksData(int workItemId)
        {
            return _workItem.GetWorkItemTasksData(workItemId);
        }

        [HttpGet]
        [Route("GetData")]
        public List<Object> GetData(Guid sprintUID, string workItemType)
        {
            return _workItem.GetData(sprintUID, workItemType);
        }

        [HttpGet]
        [Route("GetWorkItemDetails")]
        public List<dynamic>? GetWorkItemDetails(Guid SprintUID, string workItemType, string empId)
        {
            return _workItem.GetWorkItemDetails(SprintUID, workItemType, empId);
        }

        [HttpGet]
        [Route("getWorkItemTaskDetails")]
        public List<Object>? getWorkItemTaskDetails(Guid sprintUID, string workItemType, int workItemId)
        {
            return _workItem.getWorkItemTaskDetails(sprintUID, workItemType, workItemId); 
        }
    }
}
