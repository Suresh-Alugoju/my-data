﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SqlKata.Execution;
using TeamsModule_API.DTOs;
using TeamsModule_API.Models;
using TM.Application.Services.TeamMemberService;

namespace TeamsModule_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamMemberController : ControllerBase
    {
        private readonly ITeamMemberService _teamMember;

        public TeamMemberController(ITeamMemberService teamMember)
        {
            _teamMember = teamMember;
        }

        // GET: api/TeamMember
        [HttpGet]
        public IEnumerable<TdTeamMemberDTO> GetTdTeamMembers()
        {
            return _teamMember.GetTdTeamMembers();

        }
        [HttpGet("getTeamMemberBasedOnSkills/count")]
        public IEnumerable<TempDTO> GetTdTeamMembersBasedOnSkills()
        {
            return _teamMember.GetTdTeamMembersBasedOnSkills();
        }

            // GET: api/TeamMember/5
            [HttpGet("{id}")]
        public IEnumerable<TdTeamMemberDTO> GetTdTeamMember(int id)
        {
            return _teamMember.GetTdTeamMember(id);

        }

        // PUT: api/TeamMember/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public int PutTdTeamMember(int id, TdTeamMemberDTO tdTeamMemberdto)
        {
            return _teamMember.PutTdTeamMember(id, tdTeamMemberdto);
        }

        // POST: api/TeamMember
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public int PostTdTeamMember(TdTeamMemberDTO tdTeamMemberdto)
        {
            return _teamMember.PostTdTeamMember(tdTeamMemberdto);
        }

        // DELETE: api/TeamMember/5
        [HttpDelete("{id}")]
        public int DeleteTdTeamMember(int id)
        {
            return _teamMember.DeleteTdTeamMember(id);
        }

        

    }
}
