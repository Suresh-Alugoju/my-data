﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TM.Domain.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using TM.Application.Services.MailService;
using System.Text.Json.Nodes;
using Microsoft.Extensions.Options;

namespace TeamsModule_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        private readonly IMailService mailService;
        private readonly MailSettings _mailSettings;
        public EmailController(IMailService mailService, IOptions<MailSettings> mailSettings)
        {
            this.mailService = mailService;
            _mailSettings = mailSettings.Value;
        }

        [HttpPost("Send")]
        public async Task<IActionResult> Send([FromForm] MailRequest request)
        {
            try
            {
                request.ToEmail = _mailSettings.ManagerEmails;
                await mailService.SendEmailAsync(request);
                return Ok();
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }


    }
}


