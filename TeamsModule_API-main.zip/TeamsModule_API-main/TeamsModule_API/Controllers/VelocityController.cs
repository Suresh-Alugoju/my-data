﻿using Microsoft.AspNetCore.Mvc;
using TM.Application.Services.VelocityService;
using TM.Domain.Models.Common;

namespace DevOps.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class VelocityController : ControllerBase
    {
        private readonly IVelocityService _velocity;
        private readonly ILogger<VelocityController> _logger;
        static string sprints = SqlKataCommon.Table_DevOpsSprints;
        static string workItems = SqlKataCommon.Table_DevOpsWorkItems;

        public VelocityController(ILogger<VelocityController> logger, IVelocityService velocity)
        {
            _logger = logger;
            _velocity = velocity;
        }

        [HttpPost]
        [Route("GetSprintVelocityDetails/{sprintUIDs?}")]
        public List<dynamic> GetSprintVelocityDetails([FromBody] List<string> sprintUIDs)
        {
            return _velocity.GetSprintVelocityDetails(sprintUIDs);
        }

        

        [HttpPost]
        [Route("GetSprintWorkItemsCountByStatus/{sprintUIDs?}")]
        public IEnumerable<dynamic> GetSprintWorkItemsCountByStatus([FromBody] List<string> sprintUIDs)
        {
            return _velocity.GetSprintWorkItemsCountByStatus(sprintUIDs);
        }

       
    }
}
