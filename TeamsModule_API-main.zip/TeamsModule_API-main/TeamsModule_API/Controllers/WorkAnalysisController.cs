﻿using Microsoft.AspNetCore.Mvc;
using SqlKata.Execution;
using TM.Application.Services.WorkItemByStateService;
using TM.Domain.Models;
using TM.Domain.Models.Common;
using TM.Domain.Repositories.WorkAnalysisRepository;

namespace DevOps.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WorkAnalysisController : ControllerBase
    {
        private readonly ILogger<WorkAnalysisController> _logger;
        static string sprints = SqlKataCommon.Table_DevOpsSprints;
        static string workItems = SqlKataCommon.Table_DevOpsWorkItems;
        static string employees = SqlKataCommon.Table_DevOpsEmployees;

        private readonly IWorkAnalysisRepository _workItem;

        public WorkAnalysisController(IWorkAnalysisRepository workItem)
        {
            _workItem = workItem;
        }

        [HttpPost]
        [Route("GetUserStoryAnalysis")]
        public List<dynamic> GetUserStoryAnalysis([FromBody] SelectedSprintAndEmployees selectedData)
        {
            return _workItem.GetUserStoryAnalysis(selectedData);
        }

        [HttpPost]
        [Route("GetBugsAnalysis")]
        public List<dynamic> GetBugsAnalysis([FromBody] SelectedSprintAndEmployees selectedData)
        {
            return _workItem.GetBugsAnalysis(selectedData);
        }
    }

}
