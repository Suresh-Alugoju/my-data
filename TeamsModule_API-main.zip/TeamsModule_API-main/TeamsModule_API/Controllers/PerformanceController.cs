﻿using Microsoft.AspNetCore.Mvc;
using TM.Application.Services.PerformanceService;
using TM.Domain.Models;

namespace TeamsModule_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PerformanceController : Controller
    {
        private readonly IPerformanceService _performanceService;

        public PerformanceController(IPerformanceService performanceService)
        {
            _performanceService = performanceService;
        }
        [HttpGet]
        [Route("GetCompletedTasks/{EmpId}")]
        public IEnumerable<dynamic> GetCompletedTasks(int EmpId)
        {
            return _performanceService.GetCompletedTasks(EmpId);
        }
        [HttpGet]
        [Route("GetRemainingTasks/{EmpId}")]
        public IEnumerable<dynamic> GetRemainingTasks(int EmpId)
        {
            return _performanceService.GetRemainingTasks(EmpId);
        }
        [HttpGet]
        [Route("GetAllEmployees")]
        public IEnumerable<dynamic> GetAllEmployees()
        {
            return _performanceService.GetAllEmployees();
        }
        [HttpPost]
        [Route("GetSprintPlannedHr")]
        public IEnumerable<dynamic> GetSprintPlannedHr(Sprint[] sprintsList)
        {
            return _performanceService.GetSprintPlannedHr(sprintsList);
        }

        [HttpPost]
        [Route("GetSprintActualHr")]
        public IEnumerable<dynamic> GetSprintActualHr(Sprint[] sprintsList)
        {
            return _performanceService.GetSprintActualHr(sprintsList);
        }

        [HttpPost]
        [Route("GetSprintTotalPoints")]
        public IEnumerable<dynamic> GetSprintTotalPoints(Sprint[] sprintsList)
        {
            return _performanceService.GetSprintTotalPoints(sprintsList);
        }
        [HttpPost]
        [Route("GetSprintRemainingEfforts")]
        public IEnumerable<dynamic> GetSprintRemainingEfforts(Sprint[] sprintsList)
        {
            return _performanceService.GetSprintRemainingEfforts(sprintsList);
        }
        [HttpGet]
        [Route("GetEmployeeRemainingEffort/{empId}")]
        public dynamic GetEmployeeRemainingEffort(int empId, [FromQuery] string strDate, [FromQuery] string endDate)
        {
            return _performanceService.GetEmployeeRemainingEffort(empId, strDate, endDate);
        }
        [HttpGet]
        [Route("GetEmployeeTotalHour/{empId}")]
        public dynamic GetEmployeeTotalHour(int empId, [FromQuery] string strDate, [FromQuery] string endDate)
        {
            return _performanceService.GetEmployeeTotalHour(empId, strDate, endDate);
        }
        [HttpGet]
        [Route("GetCurrentSprint")]
        public dynamic GetCurrentSprint()
        {
            return _performanceService.GetCurrentSprint();
        }
        [HttpGet]
        [Route("GetCurrentSprintWorkItemCount/{sprintUID}")]
        public dynamic GetCurrentSprintWorkItemCount(string sprintUID)
        {
            return _performanceService.GetCurrentSprintWorkItemCount(sprintUID);
        }
        [HttpPost]
        [Route("GetDeviatedWorkItems")]
        public dynamic GetDeviatedWorkItems(Sprint[] sprintsList)
        {
            return _performanceService.GetDeviatedWorkItems(sprintsList);
        }
    }
}
