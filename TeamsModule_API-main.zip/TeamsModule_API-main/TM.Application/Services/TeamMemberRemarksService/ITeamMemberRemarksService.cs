﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Dto;

namespace TM.Application.Services.TeamMemberRemarksService
{
    public interface ITeamMemberRemarksService
    {
        List<TdTeamMemberRemarksDTO> GetTeamMemberRemarks(int id);
        int PostTeamMemberRemarks(TdTeamMemberRemarksDTO remarkObj);
        int DeleteTeamMemberRemarks(int id);
        public int DeleteById(int id);
    }
}
