﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Dto;
using TM.Domain.Repositories.TeamMemberRemarksRepository;
using TM.Domain.Repositories.TeamMemberRepository;

namespace TM.Application.Services.TeamMemberRemarksService
{
    public class TeamMemberRemarksService : ITeamMemberRemarksService
    {
        private readonly ITeamMemberRemarksRepository _teamMemberRemarks;
        public TeamMemberRemarksService(ITeamMemberRemarksRepository teamMemberRemarks) 
        {
            _teamMemberRemarks = teamMemberRemarks;
        }

        public List<TdTeamMemberRemarksDTO> GetTeamMemberRemarks(int id)
        {
            return _teamMemberRemarks.GetTeamMemberRemarks(id);
        }
        public int PostTeamMemberRemarks(TdTeamMemberRemarksDTO remarkObj)
        {
            return _teamMemberRemarks.PostTeamMemberRemarks(remarkObj);
        }
        public int DeleteTeamMemberRemarks(int id)
        {
            return _teamMemberRemarks.DeleteTeamMemberRemarks(id) ;
        }

        public int DeleteById(int id)
        {
            return _teamMemberRemarks.DeleteById(id) ;
        }
    }
}
