﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Repositories.CommonRepository;
using TM.Domain.Models;
using TM.Application.Services.CommonService;

namespace TeamsModule_API.Controllers
{
    public class CommonService : ICommonService
    {
        private readonly ICommonRepository _commonRepository;

        public CommonService(ICommonRepository commonService)
        {
            _commonRepository = commonService;
        }
        // GET: api/TeamDetail
        public IEnumerable<Sprint> GetSprints()
        {
            return _commonRepository.GetSprints();
        }
    }
}
