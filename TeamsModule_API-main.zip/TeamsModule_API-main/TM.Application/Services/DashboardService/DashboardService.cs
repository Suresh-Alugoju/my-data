﻿using TeamsModule_API.Models;
using TM.Domain.Repositories.DashboardRepository;
using System.Collections.Generic;

namespace TeamsModule_API.Controllers
{
    public class DashboardService : IDashboardService
    {
        private readonly IDashboardRepository _dashboard;

        public DashboardService(IDashboardRepository dashboard)
        {
            _dashboard = dashboard;
        }


        public List<TdDashboardDTO> GetTdDashboard()
        {
            return _dashboard.GetTdDashboard();

        }

    }
}