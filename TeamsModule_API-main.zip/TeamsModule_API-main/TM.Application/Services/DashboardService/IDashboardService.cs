﻿using TeamsModule_API.Models;
using TM.Domain.Repositories.DashboardRepository;
using System.Collections.Generic;

namespace TeamsModule_API.Controllers
{
    public interface IDashboardService
    {
        List<TdDashboardDTO> GetTdDashboard();
    }
}