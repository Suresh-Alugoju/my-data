﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Application.Services.MailService;
using TM.Domain.Models;

namespace TM.Application.Services.TimedHostedService
{
    public class TimedHostedService : IHostedService, IDisposable
    {
        private Timer _timer;
        private readonly IMailService mailService;
        private readonly MailSettings _mailSettings;

        public TimedHostedService(IMailService mailService, IOptions<MailSettings> mailSettings)
        {
            //Some DI here...
            this.mailService = mailService;
            _mailSettings = mailSettings.Value;
        }

        public Task StartAsync(CancellationToken stoppingToken)
        {
            Console.WriteLine("inside task");
            double TimeOfExecution = 12;

            DateTime now = DateTime.Now;
            DateTime today9am = now.Date.AddHours(TimeOfExecution);
            DateTime next9am = now <= today9am ? today9am : today9am.AddDays(1);
            TimeSpan dueTime = next9am - DateTime.Now;
            _timer = new Timer(DoWork, null, dueTime,
                TimeSpan.FromDays(1));

            return Task.CompletedTask;
        }

        private async void DoWork(object state)
        {
            //Every time when DoWork is triggered you can check time that you need
            var today = DateTime.Now.DayOfWeek;
            Console.WriteLine("HERE HRERE");
            if (today == DayOfWeek.Thursday)
            {
                var request = new Domain.Models.MailRequest();
                request.Subject = "Reminder to update WSR";
                request.Body = "This is to remind you to please update this week's WSR before EOD. <br> <br> Thanks";
                request.ToEmail = _mailSettings.TeamEmails;
                await mailService.SendEmailAsync(request);
                Console.WriteLine("Email Sent to Team");
            }
        }

        public Task StopAsync(CancellationToken stoppingToken)
        {
            _timer?.Change(Timeout.Infinite, 0);

            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }
    }
}
