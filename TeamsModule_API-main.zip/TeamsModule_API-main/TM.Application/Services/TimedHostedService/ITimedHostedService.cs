﻿using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TM.Application.Services.TimedHostedService
{
    public interface ITimedHostedService
    {
        public void TimedHostedService();
        public Task StartAsync(CancellationToken stoppingToken);
        public void DoWork(object state);
        public Task StopAsync(CancellationToken stoppingToken);
        public void Dispose();
    }
}
