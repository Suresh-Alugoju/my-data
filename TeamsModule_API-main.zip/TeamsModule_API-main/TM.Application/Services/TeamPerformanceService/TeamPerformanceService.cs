﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SqlKata;
using SqlKata.Execution;
using TM.Domain.Repositories.TeamPerformanceRepository;

namespace TM.Application.Services.TeamPerformanceService
{
    public class TeamPerformanceService : ITeamPerformanceService
    {
        private readonly ITeamPerformanceRepository db;

        public TeamPerformanceService(ITeamPerformanceRepository db)
        {
            this.db = db;
        }
        public List<dynamic> GetBugsCountByEmployees(string sprintUID)
        {
            return db.GetBugsCountByEmployees(sprintUID);
        }

        public List<dynamic> GetBugsCountBySeverityNEmployees(string sprintUID)
        {
            return db.GetBugsCountBySeverityNEmployees(sprintUID);
        }

        public List<dynamic> GetUserStoryPointsByEmployees(string sprintUID)
        {
            return db.GetUserStoryPointsByEmployees(sprintUID);
        }


        public List<dynamic> GetUserStoryPointsByStatusNEmployees(string sprintUID)
        {
            return db.GetUserStoryPointsByStatusNEmployees(sprintUID);
        }
    }
}
