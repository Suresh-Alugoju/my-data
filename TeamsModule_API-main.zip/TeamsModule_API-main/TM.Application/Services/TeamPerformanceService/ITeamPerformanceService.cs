﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SqlKata.Execution;
using SqlKata;

namespace TM.Application.Services.TeamPerformanceService
{
    public interface ITeamPerformanceService
    {
        List<dynamic> GetUserStoryPointsByStatusNEmployees(string sprintUID);
        List<dynamic> GetUserStoryPointsByEmployees(string sprintUID);
        List<dynamic> GetBugsCountBySeverityNEmployees(string sprintUID);
        List<dynamic> GetBugsCountByEmployees(string sprintUID);
    }
}
