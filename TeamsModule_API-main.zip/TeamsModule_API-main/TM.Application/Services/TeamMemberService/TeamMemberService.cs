﻿using System.Runtime.InteropServices;
using TeamsModule_API.DTOs;
using TeamsModule_API.Models;
using TM.Domain.Repositories.TeamMemberRepository;

namespace TM.Application.Services.TeamMemberService
{

    public class TeamMemberService : ITeamMemberService
    {
        private readonly ITeamMemberRepository _teamMember;

        public TeamMemberService(ITeamMemberRepository teamMember)
        {
            _teamMember = teamMember;
        }

       
        public IEnumerable<TdTeamMemberDTO> GetTdTeamMembers()
        {
            return _teamMember.GetTdTeamMembers();

        }

       
        public IEnumerable<TdTeamMemberDTO> GetTdTeamMember(int id)
        {
            return _teamMember.GetTdTeamMember(id);

        }

        
        public int PutTdTeamMember(int id, TdTeamMemberDTO tdTeamMemberdto)
        {
            return _teamMember.PutTdTeamMember(id, tdTeamMemberdto);
        }

        
        public int PostTdTeamMember(TdTeamMemberDTO tdTeamMemberdto)
        {
            return _teamMember.PostTdTeamMember(tdTeamMemberdto);
        }


        
        public int DeleteTdTeamMember(int id)
        {
            return _teamMember.DeleteTdTeamMember(id);
        }
        
public IEnumerable<TempDTO> GetTdTeamMembersBasedOnSkills()

        {

            return _teamMember.GetTdTeamMembersBasedOnSkills();



        }



    }
}
