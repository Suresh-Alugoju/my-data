﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using TeamsModule_API.DTOs;

namespace TM.Application.Services.TeamMemberService
{
    public interface ITeamMemberService
    {
        IEnumerable<TdTeamMemberDTO> GetTdTeamMembers();
        

     IEnumerable<TempDTO> GetTdTeamMembersBasedOnSkills();
        IEnumerable<TdTeamMemberDTO> GetTdTeamMember(int id);
        int PutTdTeamMember(int id, TdTeamMemberDTO tdTeamMemberdto);
        int PostTdTeamMember(TdTeamMemberDTO tdTeamMemberdto);
        int DeleteTdTeamMember(int id);
    }
}
