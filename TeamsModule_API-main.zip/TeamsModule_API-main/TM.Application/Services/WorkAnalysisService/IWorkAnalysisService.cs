﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SqlKata.Execution;
using TM.Domain.Models;

namespace TM.Application.Services.WorkAnalysisService
{
    public interface IWorkAnalysisService
    {
        List<dynamic> GetUserStoryAnalysis(SelectedSprintAndEmployees selectedData);
        List<dynamic> GetBugsAnalysis(SelectedSprintAndEmployees selectedData);
        
    }
}
