﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SqlKata.Execution;
using TM.Domain.Models;
using TM.Domain.Repositories.WorkAnalysisRepository;
using TM.Domain.Repositories.WorkItemByStateRepository;

namespace TM.Application.Services.WorkAnalysisService
{
    public class WorkAnalysisService : IWorkAnalysisService
    {
        private readonly IWorkAnalysisRepository _workItem;
        public WorkAnalysisService(IWorkAnalysisRepository workItem)
        {
            _workItem = workItem;
        }
        public List<dynamic> GetBugsAnalysis(SelectedSprintAndEmployees selectedData)
        {
            return _workItem.GetBugsAnalysis(selectedData);
        }

        List<dynamic> IWorkAnalysisService.GetUserStoryAnalysis(SelectedSprintAndEmployees selectedData)
        {
            return _workItem.GetUserStoryAnalysis(selectedData);
        }
    }
}
