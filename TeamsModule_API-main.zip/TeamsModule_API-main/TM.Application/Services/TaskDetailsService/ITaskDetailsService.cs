﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Models;

namespace TM.Application.Services.TaskDetailsService
{
    public interface ITaskDetailsService
    {
        IEnumerable<dynamic> Get();
       
    }
}
