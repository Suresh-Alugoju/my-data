﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Repositories.TaskDetailsRepository;
using TM.Domain.Repositories.WorkStatusRepository;

namespace TM.Application.Services.TaskDetailsService
{
    public class TaskDetailsService : ITaskDetailsService
    { 
        private readonly ITaskDetailsRepository _taskDetailsRepository;

        public TaskDetailsService(ITaskDetailsRepository taskDetails)
        {
            _taskDetailsRepository = taskDetails;
        }
        public IEnumerable<dynamic> Get()
        {
            return _taskDetailsRepository.Get();
        }
    }
}
