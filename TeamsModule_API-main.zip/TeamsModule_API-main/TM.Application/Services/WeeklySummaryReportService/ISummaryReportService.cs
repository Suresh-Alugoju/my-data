﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Dto;

namespace TM.Application.Services.WeeklySummaryReportService
{
    public interface ISummaryReportService
    {
        public Response GetWeeklySummaryReport(DateTime? WeekEndingDate);
        public Response AddWeeklySummaryReport(WeeklySummaryReport weeklySummaryReport);
        public Response GetDateSummaryReport(DateTime StartDate, DateTime WeekEndingDate);
        public Response UpdateWeeklySummaryReport(int SummaryId, WeeklySummaryReport weeklySummaryReport);
    }
}
