﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using TM.Domain.Dto;

using TM.Domain.Repositories.WeeklySummaryReportRepository;

namespace TM.Application.Services.WeeklySummaryReportService
{
    public class SummaryReportService :ISummaryReportService
    {
        ISummaryReportRepository _summaryReportRepository;
        public SummaryReportService(ISummaryReportRepository summaryReportRepository) 
        {
            _summaryReportRepository = summaryReportRepository;
        }
        public Response GetWeeklySummaryReport(DateTime? WeekEndingDate)
        {
            Response response = new Response();
            dynamic actionItems = _summaryReportRepository.GetSummaryReport(WeekEndingDate);
                if (actionItems != null)
                {
                    response.Data = JsonSerializer.Serialize(actionItems);
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = "Data Retrieved Successfully";
                }            
            return response;

        }
        public Response AddWeeklySummaryReport(WeeklySummaryReport weeklySummaryReport)
        {
            Response response = new Response();
            bool datainserted = _summaryReportRepository.AddWeeklySummaryReport(weeklySummaryReport);
                if (datainserted)
                {
                    response.StatusCode = (int)HttpStatusCode.Created;
                    response.Message = "Data Added Successfully";
                }
            
            return response;
        }

        public Response GetDateSummaryReport(DateTime StartDate, DateTime WeekEndingDate)
        {
            Response response = new Response();
            dynamic actionItems = _summaryReportRepository.GetDataSummaryReport(StartDate, WeekEndingDate);
                
                if (actionItems != null)
                {
                    response.Data = JsonSerializer.Serialize(actionItems);
                    response.StatusCode = (int)HttpStatusCode.OK;
                    response.Message = "Data Retrieved Successfully";
                }
                
            return response;

        }

        public Response UpdateWeeklySummaryReport(int SummaryId, WeeklySummaryReport weeklySummaryReport)
        {
            Response response = new Response();
            bool datainserted = _summaryReportRepository.UpdateWeeklySummaryReport(SummaryId, weeklySummaryReport);
                if (datainserted)
                {
                    response.StatusCode = (int)HttpStatusCode.Created;
                    response.Message = "Data Updated Successfully";
                }
            
            return response;
        }
    }
}
