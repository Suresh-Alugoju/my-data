﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Dto;
using TM.Domain.Repositories.TeamMemberRepository;
using TM.Domain.Repositories.TeamMemberSkillsRepository;

namespace TM.Application.Services.TeamMemberSkillsService
{
    public class TeamMemberSkillsService : ITeamMemberSkillsService
    {
        private readonly ITeamMemberSkillsRepository _teamMemberSkills;

        public TeamMemberSkillsService(ITeamMemberSkillsRepository teamMemberSkills)
        {
            _teamMemberSkills = teamMemberSkills;
        }

        public List<TdTeamMemberSkillsDTO> GetTeamMemberSkills(int id)
        {
            return _teamMemberSkills.GetTeamMemberSkills(id);
        }
        public int PostTeamMemberSkills(TdTeamMemberSkillsDTO skillsdto)
        {
            return _teamMemberSkills.PostTeamMemberSkills(skillsdto);
        }
        public int DeleteTeamMemberSkills(int id)
        {
            return _teamMemberSkills.DeleteTeamMemberSkills(id);
        }
        public int DeleteById(int id)
        {
            return _teamMemberSkills.DeleteById(id);

        }
    }
}
