﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Dto;

namespace TM.Application.Services.TeamMemberSkillsService
{
    public interface ITeamMemberSkillsService
    {
        List<TdTeamMemberSkillsDTO> GetTeamMemberSkills(int id);
        int PostTeamMemberSkills(TdTeamMemberSkillsDTO skillsdto);
        int DeleteTeamMemberSkills(int id);
        public int DeleteById(int id);
    }
}
