﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Repositories.TeamDetailsRepository;
using TeamsModule_API.Models;
using TM.Domain.Models;
using TM.Application.Services.WorkStatusService;
using TM.Domain.Repositories.WorkStatusRepository;

namespace TeamsModule_API.Controllers
{
    public class WorkStatusService : IWorkStatusService
    {

        private readonly IWorkStatusRepository _workStatusRepository;

        public WorkStatusService(IWorkStatusRepository workStatus)
        {
            _workStatusRepository = workStatus;
        }
        //// GET: api/TeamDetail
        //public IEnumerable<Sprints> Get()
        //{
        //    return _workStatusRepository.Get();
        //}
        public IEnumerable<dynamic> GetStatusCountData(List<string> sprintUIDs)
        {
            return _workStatusRepository.GetStatusCountData(sprintUIDs);
        }

        public IEnumerable<dynamic> GetBugSeverityCount(List<string> sprintUIDs)
        {
            return _workStatusRepository.GetBugSeverityCount(sprintUIDs);
        }
        public IEnumerable<dynamic> GetUserStoryPointsCount(List<string> sprintUIDs)
        {
            return _workStatusRepository.GetUserStoryPointsCount(sprintUIDs);
        }
    }
}
