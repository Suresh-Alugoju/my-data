﻿using TeamsModule_API.DTOs;
using TM.Domain.Models;
using TM.Domain.Repositories.TeamDetailsRepository;

namespace TM.Application.Services.WorkStatusService
{

    public interface IWorkStatusService
    {
      //  IEnumerable<Sprints> Get();
        IEnumerable<dynamic> GetStatusCountData(List<string> sprintUIDs);
        IEnumerable<dynamic> GetBugSeverityCount(List<string> sprintUIDs);
        IEnumerable<dynamic> GetUserStoryPointsCount(List<string> sprintUIDs);
    }
}
