﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeamsModule_API.Models;
using TM.Domain.Models;
using TM.Domain.Repositories.SprintDataRepository;
using TM.Domain.Repositories.TeamDetailsRepository;

namespace TM.Application.Services.SprintDataService
{
    public class SprintDataService : ISprintDataService
    {
        private readonly ISprintDataRepository _sprintDataRepository;

        public SprintDataService(ISprintDataRepository sprintData)
        {
            _sprintDataRepository = sprintData;
        }
        // GET: api/SprintData
        public IEnumerable<SprintData> Get()
        {
            return _sprintDataRepository.Get();
        }
        public int Upsert(SprintData sprintData)
        {
            return _sprintDataRepository.Upsert(sprintData);
        }
        public int UpsertSprint(Sprint sprint)
        {
            return _sprintDataRepository.UpsertSprint(sprint);
        }
    }
}
