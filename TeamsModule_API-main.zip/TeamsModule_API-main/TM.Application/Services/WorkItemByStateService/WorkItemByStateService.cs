﻿using TM.Domain.Models;
using TM.Domain.Repositories.WorkItemByStateRepository;

namespace TM.Application.Services.WorkItemByStateService
{
    public class WorkItemByStateService : IWorkItemByStateService
    {
        private readonly IWorkItemByStateRepository _workItem;
        public WorkItemByStateService(IWorkItemByStateRepository workItem)
        {
            _workItem = workItem;
        }

        IEnumerable<WorkItemByState> IWorkItemByStateService.Get()
        {
            return _workItem.Get();
        }

        List<object> IWorkItemByStateService.GetData(Guid sprintUID, string workItemType)
        {
            return _workItem.GetData(sprintUID,workItemType);
        }

        List<object>? IWorkItemByStateService.GetEmployeeTaskCountByStatus(Guid SprintUID, string workItemType, string workItemId)
        {
            return _workItem.GetEmployeeTaskCountByStatus(SprintUID,workItemType,workItemId);
        }

        List<object>? IWorkItemByStateService.GetEmployeeWorkItemCountByStatus(Guid SprintUID, string workItemType)
        {
            return _workItem.GetEmployeeWorkItemCountByStatus(SprintUID,workItemType);
        }

        List<dynamic>? IWorkItemByStateService.GetWorkItemDetails(Guid SprintUID, string workItemType, string empId)
        {
            return _workItem.GetWorkItemDetails(SprintUID,workItemType,empId);
        }

        IEnumerable<WorkItem>? IWorkItemByStateService.GetWorkItems()
        {
            return _workItem.GetWorkItems();
        }

        List<object>? IWorkItemByStateService.GetWorkItemsBySprint(Guid sprintUID, string workItemType)
        {
            return _workItem.GetWorkItemsBySprint(sprintUID,workItemType);
        }

        List<object>? IWorkItemByStateService.getWorkItemTaskDetails(Guid sprintUID, string workItemType, int workItemId)
        {
            return _workItem.getWorkItemTaskDetails(sprintUID,workItemType,workItemId);
        }

        List<object> IWorkItemByStateService.GetWorkItemTasksData(int workItemId)
        {
            return _workItem.GetWorkItemTasksData(workItemId);
        }
    }
}
