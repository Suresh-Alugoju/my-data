﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Models;

namespace TM.Application.Services.WorkItemByStateService
{
    public interface IWorkItemByStateService
    {
        IEnumerable<WorkItemByState> Get();
        IEnumerable<WorkItem>? GetWorkItems();
        List<Object>? GetWorkItemsBySprint(Guid sprintUID, string workItemType);
        List<object>? GetEmployeeWorkItemCountByStatus(Guid SprintUID, string workItemType);
        List<object>? GetEmployeeTaskCountByStatus(Guid SprintUID, string workItemType, string workItemId);
        List<Object> GetWorkItemTasksData(int workItemId);
        List<Object> GetData(Guid sprintUID, string workItemType);
        List<dynamic>? GetWorkItemDetails(Guid SprintUID, string workItemType, string empId);
        List<Object>? getWorkItemTaskDetails(Guid sprintUID, string workItemType, int workItemId);
    }
}
