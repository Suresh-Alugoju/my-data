﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SqlKata.Execution;
using TM.Domain.Repositories.VelocityRepository;
using TM.Domain.Repositories.WorkItemByStateRepository;

namespace TM.Application.Services.VelocityService
{
    public class VelocityService : IVelocityService
    {
        private readonly IVelocityRepository _velocity;
        public VelocityService(IVelocityRepository velocity)
        {
            _velocity = velocity;
        }

        public IEnumerable<dynamic> GetSprintWorkItemsCountByStatus(List<string> sprintUIDs)
        {
            return _velocity.GetSprintWorkItemsCountByStatus(sprintUIDs);
        }

        List<dynamic> IVelocityService.GetSprintVelocityDetails(List<string> sprintUIDs)
        {
            return _velocity.GetSprintVelocityDetails(sprintUIDs);
        }
    }
}
