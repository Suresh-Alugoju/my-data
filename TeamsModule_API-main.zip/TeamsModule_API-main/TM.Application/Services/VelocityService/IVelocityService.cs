﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SqlKata.Execution;

namespace TM.Application.Services.VelocityService
{
    public interface IVelocityService
    {
        List<dynamic> GetSprintVelocityDetails(List<string> sprintUIDs);
        IEnumerable<dynamic> GetSprintWorkItemsCountByStatus(List<string> sprintUIDs);
    }
}
