﻿using TeamsModule_API.Models;

using TM.Domain.Repositories.TeamDetailsRepository;

namespace TeamsModule_API.Controllers
{

    public class TeamDetailService : ITeamDetailService
    {

        private readonly ITeamDetailsRepository _teamDetails;

        public TeamDetailService(ITeamDetailsRepository teamDetails)
        {
            _teamDetails = teamDetails;
        }

        // GET: api/TeamDetail
        public IEnumerable<TdTeamDetailDTO> GetTdTeamDetails()
        {
            return _teamDetails.GetTdTeamDetails();
        }

        // GET: api/TeamDetail/5
        public IEnumerable<TdTeamDetailDTO> GetTdTeamDetail(int id)
        {
            return _teamDetails.GetTdTeamDetail(id);

        }

        // PUT: api/TeamDetail/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        public int PutTdTeamDetail(int id, TdTeamDetailDTO tdTeamDetaildto)
        {
            return _teamDetails.PutTdTeamDetail(id, tdTeamDetaildto);
        }

        // POST: api/TeamDetail
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        public int PostTdTeamDetail(TdTeamDetailDTO tdTeamDetaildto)
        {
            return _teamDetails.PostTdTeamDetail(tdTeamDetaildto);
        }

        // DELETE: api/TeamDetail/5
        public int DeleteTdTeamDetail(int id)
        {
            return _teamDetails.DeleteTdTeamDetail(id);

        }

    }
}
