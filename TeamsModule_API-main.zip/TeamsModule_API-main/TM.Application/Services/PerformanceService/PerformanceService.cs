﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Models;
using TM.Domain.Repositories.PerformanceRepository;
using TM.Domain.Repositories.TeamMemberRemarksRepository;

namespace TM.Application.Services.PerformanceService
{
    public class PerformanceService : IPerformanceService
    {
        private readonly IPerformanceRepository _performanceRepository;
        public PerformanceService(IPerformanceRepository performanceRepository)
        {
            _performanceRepository = performanceRepository;
        }
        public IEnumerable<dynamic> GetCompletedTasks(int EmpId)
        {
            return _performanceRepository.GetCompletedTasks(EmpId);
        }
        public IEnumerable<dynamic> GetRemainingTasks(int EmpId)
        {
            return _performanceRepository.GetRemainingTasks(EmpId);
        }
        public IEnumerable<dynamic> GetAllEmployees()
        {
            return _performanceRepository.GetAllEmployees();
        }
        public IEnumerable<dynamic> GetSprintPlannedHr(Sprint[] sprintsList)
        {
            return _performanceRepository.GetSprintPlannedHr(sprintsList);
        }
        public IEnumerable<dynamic> GetSprintActualHr(Sprint[] sprintsList)
        {
            return _performanceRepository.GetSprintActualHr(sprintsList);
        }
        public IEnumerable<dynamic> GetSprintTotalPoints(Sprint[] sprintsList)
        {
            return _performanceRepository.GetSprintTotalPoints(sprintsList);
        }
        public IEnumerable<dynamic> GetSprintRemainingEfforts(Sprint[] sprintsList)
        {
            return _performanceRepository.GetSprintRemainingEfforts(sprintsList);
        }
        public dynamic GetEmployeeRemainingEffort(int empId,  string strDate,  string endDate)
        {
            return _performanceRepository.GetEmployeeRemainingEffort(empId, strDate, endDate);
        }
        public dynamic GetEmployeeTotalHour(int empId,  string strDate,  string endDate)
        {
            return _performanceRepository.GetEmployeeTotalHour(empId, strDate, endDate);
        }
        public dynamic GetCurrentSprint()
        {
            return _performanceRepository.GetCurrentSprint();
        }
        public dynamic GetCurrentSprintWorkItemCount(string sprintUID)
        {
            return _performanceRepository.GetCurrentSprintWorkItemCount(sprintUID);
        }
        public dynamic GetDeviatedWorkItems(Sprint[] sprintsList)
        {
            return _performanceRepository.GetDeviatedWorkItems(sprintsList);
        }
    }
}