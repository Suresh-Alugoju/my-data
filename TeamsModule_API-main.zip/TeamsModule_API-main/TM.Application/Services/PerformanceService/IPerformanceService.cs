﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TM.Domain.Models;

namespace TM.Application.Services.PerformanceService
{
    public interface IPerformanceService
    {
        IEnumerable<dynamic> GetCompletedTasks(int EmpId);
        IEnumerable<dynamic> GetRemainingTasks(int EmpId);
        IEnumerable<dynamic> GetAllEmployees();
        IEnumerable<dynamic> GetSprintPlannedHr(Sprint[] sprintsList);
        IEnumerable<dynamic> GetSprintActualHr(Sprint[] sprintsList);
        IEnumerable<dynamic> GetSprintTotalPoints(Sprint[] sprintsList);
        IEnumerable<dynamic> GetSprintRemainingEfforts(Sprint[] sprintsList);
        dynamic GetEmployeeRemainingEffort(int empId, string strDate, string endDate);
        dynamic GetEmployeeTotalHour(int empId, string strDate, string endDate);
        dynamic GetCurrentSprint();
        dynamic GetCurrentSprintWorkItemCount(string sprintUID);
        dynamic GetDeviatedWorkItems(Sprint[] sprintsList);
    }
}
