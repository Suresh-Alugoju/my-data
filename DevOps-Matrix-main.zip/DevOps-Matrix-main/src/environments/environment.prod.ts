export const environment = {
  production: true,
  baseUrl:'http://10.53.106.29:128/'

};
