export class WSR_ActionItems {
    ActionItemID: number
    SummaryID: number
    ActionItem: string
    Owner: string
    ETA: Date
    Status: string
    Remarks: string
    isActive: boolean
    CompletionDate : Date

}