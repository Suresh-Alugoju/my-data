export class WSR_Teams {
    TeamID: number
    TeamName: string
    SummaryID: number
    LeadName: string
    TaskCompleted: string
    TaskInProgress: string
    CurrentWeekPlan: string
}