export class WSR_RemarkHistory {
    RemarkID: number
    SummaryID: number
    ActionItemID: number
    Remark: string
    AddedDate: Date
}