export enum Role {
    Admin = 'Admin',
    Manager = 'Manager',
    User = 'User',
    Superuser = 'Superuser'
}