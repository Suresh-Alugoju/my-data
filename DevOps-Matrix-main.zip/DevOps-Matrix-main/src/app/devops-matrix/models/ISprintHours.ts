export interface ISprintHours{
    SprintNumber:string;
    Hr:number;
}