export interface ISprintTotalPoints{
    SprintNumber:string;
    TotalPoints:number;
}