import { Component } from '@angular/core';

@Component({
  selector: 'app-devops-matrix',
  templateUrl: './devops-matrix.component.html',
  styleUrls: ['./devops-matrix.component.css']
})
export class DevopsMatrixComponent {

}
